# Code for the additional analyses of the revised manuscript

These folders extend the authors' original code repository (`EV_Ramp_Forecasting/`, with `src/`, `results/`,
`vendor/` and `data/raw/`). Copy the three folders into the repository root:

```
EV_Ramp_Forecasting/
├── src/                  (original code; CRAG-Net in PyTorch and all baselines)
├── results/              (original runs, tables, released checkpoints, seed-averaged test forecasts)
├── data/raw/UrbanEV, data/raw/ST-EVCDP   (public datasets, as cloned from the authors' GitHub repositories)
├── revision_data/        data loader with zone prices, price-step event study, statistical baselines
├── revision/             NumPy CRAG-Net, predictability decomposition, semi-synthetic experiment, reserve sizing
└── revision_figures/     Figs. 3, 7, 11, 12, graphical abstract, Table 7 and the Supplementary Material
```

| Script | Produces | Section |
|---|---|---|
| `revision_data/price_sync.py` | `revision/out/price_sync.json` (two-way FE event study, Eq. 1) | 4.1, Table S5 |
| `revision/predictability.py UrbanEV ST-EVCDP` | `revision/out/predictability_<data>.json` (Shapley and unique contributions, ridge and GBRT) | 4.3, Tables 4, S6–S7 |
| `revision/predictability.py --synthetic 1.0 gbrt` | decomposition on data with injected coupling | 6, Table S8 |
| `revision/np_crag.py` | NumPy/autograd port of CRAG-Net; loads the released `.pt` checkpoints without PyTorch | 5–7 |
| `revision/real_alpha.py` | learned fusion weights of the released checkpoints | 5.4, Fig. 11a |
| `revision/semi_synth.py KAPPA VARIANT SEED` (`run_synth.sh`, `run_synth_nb0.sh`) | `revision/out/synth_k*_*.json` | 6, Table 7 |
| `revision/reserve.py` (env. `ACI_GAMMA`) | `revision/out/reserve.json` (online conformal reserve bands) | 7, Table 8, S10–S11 |
| `revision/fig_numbers.py` | `revision/out/fig_numbers.json` (per-horizon errors, regional error by target hour, case-study window; numbers quoted with Figs. 9–10 and Supplementary Fig. S3, which are drawn by `src/report.py` of the original repository) | 5.3 |
| `revision/graph_numbers.py` | `revision/out/graph_numbers.json` (correlation-matrix structure and edge lengths of the geographic and correlation graphs; Figs. 4 and 6 are drawn by `src/analysis.py` and `src/graph_map.py`) | 4.2 |
| `revision_figures/*.py` | figures, Table 7 and `Supplementary_Material.md` | — |

`revision/out/` contains the result files used in the manuscript. Requirements: Python 3.10+, NumPy, pandas,
SciPy, scikit-learn, matplotlib and the vendored `autograd` package of the original repository (no PyTorch is
needed for the revision scripts). Training runs of `semi_synth.py` take about one hour each on one CPU thread.
