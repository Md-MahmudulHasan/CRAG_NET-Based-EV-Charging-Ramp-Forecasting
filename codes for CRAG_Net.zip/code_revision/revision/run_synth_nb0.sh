#!/bin/bash
# Second wave of the semi-synthetic experiment: neutral (uniform) initialisation of the fusion weights.
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
until [ -f out/synth_k1.0_nograph_s0.json ]; do sleep 20; done
python3 semi_synth.py 1.0 full_nb0 0 > logs/k1_full_nb0.log 2>&1
python3 semi_synth.py 0.0 full_nb0 0 > logs/k0_full_nb0.log 2>&1
