"""Controlled semi-synthetic spatial-coupling experiment (revision, analysis C).

Real UrbanEV loads X are augmented with an injected, lagged spillover from geographic neighbours:
    X'_{t,i} = X_{t,i} * exp(GAMMA * kappa * z_{t-lag,i}),   z_{t,i} = (sum_j W_ij r_{t,j}) / sd_train(.)
where r = (X - P)/sigma is the zone-standardised deseasonalised residual (P: training calendar profile),
W is the row-normalised geographic kNN graph WITHOUT self loops, lag = 3 steps (inside the 12-step input
window, so every horizon can exploit it) and GAMMA = 0.25 (a one-s.d. neighbour anomaly modulates the
zone's load by about 25 % at kappa = 1). The multiplicative form keeps loads non-negative without clipping.
kappa = 0 is the real data.
CRAG-Net (final configuration) is retrained from scratch on X' with the identical recipe; we record the
learned fusion weights over {none, geo, corr, adp}, and the test accuracy, together with a graph-free
variant (only the 'none' branch) to measure what the graph adds.
Usage: python semi_synth.py KAPPA VARIANT SEED   (VARIANT in {full, nograph, full_nb0})
"full_nb0" initialises the null-option bias at 0 (uniform initial fusion weights) instead of +2.
"""
import json, os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src")
sys.path.insert(0, SRC)
import numpy as onp
import pipeline, data as rawdata
from graphs import build_graphs, seasonal_profile, gaussian_kernel_graph
import np_crag

LAG = 3
GAMMA = 0.25


def augmented(name, kappa):
    ds = rawdata.load(name)
    X = ds["X"].astype(onp.float64)
    n_tr, _ = rawdata.split_index(len(X))
    prof = seasonal_profile(X[:n_tr], ds["tod"][:n_tr], ds["offday"][:n_tr], ds["steps_per_day"])
    R = X - prof[ds["offday"].astype(int), ds["tod"]]
    sig = R[:n_tr].std(0) + 1e-6
    r = R / sig
    A = gaussian_kernel_graph(ds["D"], k=10)
    W = A / onp.maximum(A.sum(1, keepdims=True), 1e-12)
    z = r @ W.T
    z = z / z[:n_tr].std()
    S = onp.zeros_like(X)
    S[LAG:] = z[:-LAG]
    Xn = X * onp.exp(GAMMA * kappa * S)
    Pn = seasonal_profile(Xn[:n_tr], ds["tod"][:n_tr], ds["offday"][:n_tr], ds["steps_per_day"])
    Rn = Xn - Pn[ds["offday"].astype(int), ds["tod"]]
    info = dict(kappa=kappa, lag=LAG, gamma=GAMMA,
                injected_share_of_residual_var=float(onp.var((Xn - X)[:n_tr]) / onp.var(Rn[:n_tr])),
                regional_mean_change_pct=float(100 * (Xn.sum(1).mean() / X.sum(1).mean() - 1)))
    ds = dict(ds); ds["X"] = Xn.astype(onp.float32)
    return ds, info


def make_data(name, kappa):
    ds, info = augmented(name, kappa)
    orig = pipeline.load
    pipeline.load = lambda n: ds
    try:
        D = pipeline.Data(name)
    finally:
        pipeline.load = orig
    G = build_graphs(ds, D.n_tr)
    return D, G, info


def metrics(D, pred_kw, split="test"):
    idx = D.idx[split]
    y = D.Traw[idx[:, None] + onp.arange(1, D.H + 1)[None]]
    e = pred_kw - y
    return dict(zone_MAE=float(onp.abs(e).mean()), region_MAE=float(onp.abs(e.sum(2)).mean()))


if __name__ == "__main__":
    kappa, variant, seed = float(sys.argv[1]), sys.argv[2], int(sys.argv[3])
    rounds = int(os.environ.get("ROUNDS", 25))
    D, G, info = make_data("UrbanEV", kappa)
    Gm = {"geo_rw": G["geo_rw"], "corr_rw": G["corr_rw"]}
    nb = 0.0 if variant == "full_nb0" else 2.0
    if variant == "nograph":
        Gm = dict(Gm, only_none=True)
    t0 = time.time()
    p, best, hist = np_crag.train(D, Gm, seed=seed, rounds=rounds, verbose=True, none_bias=nb)
    pred = np_crag.predict(p, D, Gm, "test")
    out = dict(info, variant=variant, seed=seed, best_val=best, hist=hist, minutes=(time.time() - t0) / 60,
               test=metrics(D, pred))
    alpha = onp.asarray(np_crag.fusion_weights(p, 3))         # (N,L,G)
    p0 = np_crag.init_params(onp.random.default_rng(seed), D.N, D.T_in, D.F, D.H, D.n_slots, none_bias=nb)
    out["alpha_init_mean"] = onp.asarray(np_crag.fusion_weights(p0, 3)).mean((0, 1)).tolist()
    out["alpha_per_zone"] = alpha.mean(1).tolist()
    out["gw_norm"] = [float(onp.linalg.norm(p[f"gw{l}"])) for l in range(3)]
    out["gw_norm_init"] = [float(onp.linalg.norm(p0[f"gw{l}"])) for l in range(3)]
    out["alpha_mean"] = alpha.mean((0, 1)).tolist()
    out["alpha_mean_by_layer"] = alpha.mean(0).tolist()
    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    json.dump(out, open(os.path.join(HERE, "out", f"synth_k{kappa}_{variant}_s{seed}.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != "hist"}, indent=1))
