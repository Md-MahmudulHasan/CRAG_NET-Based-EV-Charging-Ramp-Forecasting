"""From forecasts to ramp reserves (revision, analysis D).

For each regional forecast X_hat_{t+h} issued at origin t, the operator holds an upward and a downward
reserve that should cover the forecast error e = X_{t+h} - X_hat_{t+h} with probability 1 - alpha (alpha = 0.05).
The reserve band is sized from past errors only (online split-conformal / empirical-quantile sizing):
at origin t, the usable errors are those whose target time has already been observed (t' + h <= t), taken
from the validation period and from the part of the test period before t.

Schemes
  static : one band per horizon from all past errors;
  hourly : a normalised band (locally weighted split conformal, Lei et al. 2018): past errors are divided by
           the mean absolute past error of their target hour of day, quantiles of these scaled errors are pooled
           over all hours, and the band is rescaled by the scale of the target hour (overall scale when fewer
           than MIN_N past errors exist for that hour).
In both schemes the working quantile level is adapted online with adaptive conformal inference
(Gibbs & Candes 2021, step GAMMA) so that long-run coverage tracks 1 - alpha under distribution shift;
widths are therefore compared at (approximately) equal coverage.
"Ramp hours" are the three target hours with the highest training-period frequency of regional ramp events.
Models with validation-period forecasts: Persistence, SNaive-D, SDiff (closed form) and CRAG-Net (seed mean
of the three released checkpoints, evaluated with the NumPy port, which reproduces the PyTorch test forecasts).
Reported on the test period: empirical coverage, mean band width (MW), mean width in the three ramp hours and
elsewhere, and the interval score (Gneiting & Raftery 2007).
Output: out/reserve.json
"""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src")
sys.path.insert(0, SRC)
import numpy as np
from pipeline import Data
from graphs import build_graphs
import np_crag

ALPHA = 0.05
MIN_N = 10
GAMMA = float(os.environ.get("ACI_GAMMA", 0.01))
ROOT = os.path.join(HERE, "..")
CACHE = os.path.join(HERE, "out", "cache")


def crag_forecasts(D, G, split):
    os.makedirs(CACHE, exist_ok=True)
    f = os.path.join(CACHE, f"crag_{D.name}_{split}.npy")
    if os.path.exists(f):
        return np.load(f)
    Gm = {"geo_rw": G["geo_rw"], "corr_rw": G["corr_rw"]}
    out = []
    for s in range(3):
        sd = np_crag.load_state_dict(os.path.join(ROOT, "results", "runs_torch", D.name, f"CRAG-Net_s{s}", "model.pt"))
        p = np_crag.params_from_torch(sd)
        out.append(np_crag.predict(p, D, Gm, split))
    F = np.mean(out, 0)
    np.save(f, F)
    return F


def closed_form(D, kind, idx):
    X = D.Traw; S = D.spd; H = D.H
    fut = idx[:, None] + np.arange(1, H + 1)[None]
    if kind == "Persistence":
        return np.repeat(X[idx][:, None], H, 1)
    if kind == "SNaive-D":
        return X[fut - S]
    if kind == "SDiff":
        return X[idx][:, None] + X[fut - S] - X[idx - S][:, None]
    raise ValueError(kind)


def ramp_hours(D, k=3):
    """The k target hours with the highest training-period frequency of regional ramp events
    (|one-step regional ramp| above its 90th percentile). Training data only."""
    X = D.Traw[:D.n_tr].sum(1)
    r = np.abs(np.diff(X))
    ev = r > np.quantile(r, 0.9)
    hour = (D.ds["tod"][1:D.n_tr] * 24) // D.spd
    freq = np.array([ev[hour == hh].mean() for hh in range(24)])
    return sorted(np.argsort(-freq)[:k].tolist()), freq


def aci_band(e_all, t_all, hr_all, it, h, hour, scheme, gamma=GAMMA):
    """Online empirical-quantile band with adaptive conformal inference (Gibbs & Candes 2021):
    the working miscoverage level a_t is updated with every miss that has become observable."""
    n = len(it)
    lo = np.zeros(n); hi = np.zeros(n)
    a_t = ALPHA
    pending = []                                   # (time when observable, miss indicator) of issued bands
    y_te = e_all[-n:]
    for k, t in enumerate(it):
        # incorporate misses observed up to time t (feedback is delayed by the horizon h)
        still = []
        for (tobs, miss) in pending:
            if tobs <= t:
                a_t = a_t + gamma * (ALPHA - miss)
            else:
                still.append((tobs, miss))
        pending = still
        avail = t_all <= t
        q = float(np.clip(a_t, 0.0, 0.5))
        if scheme == "hourly":
            # normalised (locally weighted) band: hour-specific scale = mean |error| of past errors with the
            # same target hour; quantiles of the scaled errors are pooled over all hours
            ea, ha = e_all[avail], hr_all[avail]
            scale_all = np.ones(len(ea))
            hrs = np.unique(ha)
            sc = {}
            for hh in hrs:
                mm = ha == hh
                sc[hh] = np.mean(np.abs(ea[mm])) if mm.sum() >= MIN_N else np.mean(np.abs(ea))
                scale_all[mm] = sc[hh]
            s_t = sc.get(hour[t + h], np.mean(np.abs(ea)))
            ql, qh = np.quantile(ea / scale_all, [q / 2, 1 - q / 2])
            lo[k], hi[k] = ql * s_t, qh * s_t
        else:
            lo[k], hi[k] = np.quantile(e_all[avail], [q / 2, 1 - q / 2])
        y = y_te[k]
        pending.append((t + h, float((y < lo[k]) or (y > hi[k]))))
    return lo, hi


def evaluate(D, F_val, F_te, rhours):
    X = D.Traw
    H, S = D.H, D.spd
    iv, it = D.idx["val"], D.idx["test"]
    Yv = np.stack([X[iv + h].sum(1) for h in range(1, H + 1)], 1) / 1e3      # MW
    Yt = np.stack([X[it + h].sum(1) for h in range(1, H + 1)], 1) / 1e3
    ev = Yv - F_val.sum(2) / 1e3
    et = Yt - F_te.sum(2) / 1e3
    hour = (D.ds["tod"] * 24) // S
    res = {}
    for scheme in ["static", "hourly"]:
        cov, wid, isc, wb, wo, upb, upo = [], [], [], [], [], [], []
        W_all, HR_all, LO_all, HI_all = [], [], [], []
        for h in range(1, H + 1):
            e_all = np.r_[ev[:, h - 1], et[:, h - 1]]
            t_all = np.r_[iv + h, it + h]
            lo, hi = aci_band(e_all, t_all, hour[t_all], it, h, hour, scheme)
            y = et[:, h - 1]
            w = hi - lo
            inside = (y >= lo) & (y <= hi)
            score = w + (2 / ALPHA) * (np.maximum(lo - y, 0) + np.maximum(y - hi, 0))
            isb = np.isin(hour[it + h], rhours)
            cov.append(inside.mean()); wid.append(w.mean()); isc.append(score.mean())
            wb.append(w[isb].mean()); wo.append(w[~isb].mean())
            upb.append(hi[isb].mean()); upo.append(hi[~isb].mean())
            W_all.append(w); HR_all.append(hour[it + h]); LO_all.append(lo); HI_all.append(hi)
        res[scheme] = dict(coverage=float(np.mean(cov)), width_MW=float(np.mean(wid)), interval_score=float(np.mean(isc)),
                           width_ramp_hours_MW=float(np.mean(wb)), width_other_MW=float(np.mean(wo)),
                           up_ramp_hours_MW=float(np.mean(upb)), up_other_MW=float(np.mean(upo)),
                           coverage_h=[float(c) for c in cov], width_h=[float(x) for x in wid],
                           width_by_target_hour=[float(np.concatenate(W_all)[np.concatenate(HR_all) == hh].mean()) for hh in range(24)],
                           up_by_target_hour=[float(np.concatenate(HI_all)[np.concatenate(HR_all) == hh].mean()) for hh in range(24)],
                           down_by_target_hour=[float(-np.concatenate(LO_all)[np.concatenate(HR_all) == hh].mean()) for hh in range(24)])
    # width by target hour (hourly scheme, all horizons pooled) for plotting
    res["test_MAE_MW"] = float(np.abs(et).mean())
    res["val_MAE_MW"] = float(np.abs(ev).mean())
    return res


if __name__ == "__main__":
    out = {}
    pz = np.load(os.path.join(ROOT, "results", "predictions_test_seedmean.npz"))
    for name in ["UrbanEV", "ST-EVCDP"]:
        D = Data(name)
        G = build_graphs(D.ds, D.n_tr)
        rh, freq = ramp_hours(D)
        out[name] = {"ramp_hours": rh, "ramp_event_freq_by_hour": freq.tolist()}
        Fv = crag_forecasts(D, G, "val"); Ft = crag_forecasts(D, G, "test")
        ref = pz[f"{name}__CRAG-Net"].astype(np.float64)
        out[name]["port_check_max_abs_diff_kW"] = float(np.abs(Ft - ref).max())
        out[name]["port_check_zone_MAE_kW"] = float(np.abs(Ft - D.Traw[D.idx["test"][:, None] + np.arange(1, D.H + 1)[None]]).mean())
        out[name]["CRAG-Net"] = evaluate(D, Fv, Ft, rh)
        for kind in ["Persistence", "SNaive-D", "SDiff"]:
            out[name][kind] = evaluate(D, closed_form(D, kind, D.idx["val"]), closed_form(D, kind, D.idx["test"]), rh)
        print(name, json.dumps({k: (v if not isinstance(v, dict) else {s: (round(v[s]["coverage"], 3), round(v[s]["width_MW"], 2), round(v[s]["width_ramp_hours_MW"], 2), round(v[s]["width_other_MW"], 2), round(v[s]["interval_score"], 2)) for s in ("static", "hourly")}) for k, v in out[name].items()}), flush=True)
    json.dump(out, open(os.path.join(HERE, "out", "reserve.json"), "w"), indent=1)
