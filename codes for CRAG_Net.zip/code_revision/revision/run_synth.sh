#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
( python3 semi_synth.py 0.0 full 0 > logs/k0_full.log 2>&1; python3 semi_synth.py 0.5 full 0 > logs/k05_full.log 2>&1; python3 semi_synth.py 0.0 nograph 0 > logs/k0_nograph.log 2>&1 ) &
( python3 semi_synth.py 1.0 full 0 > logs/k1_full.log 2>&1; python3 semi_synth.py 1.0 nograph 0 > logs/k1_nograph.log 2>&1 ) &
wait
