"""NumPy/autograd port of the final CRAG-Net (PyTorch class CRAGNetMLP, config
{"graphs": ["none","geo","corr","adp"], "graph_ln": false, "prior": null}).

Used in the revision to (i) load the released PyTorch weights without PyTorch and reproduce the
published test metrics, (ii) produce validation-period forecasts for reserve calibration, and
(iii) train CRAG-Net on semi-synthetic data in the controlled spatial-coupling experiment.
"""
from __future__ import annotations

import os
import pickle
import sys
import zipfile
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "vendor", "autograd"))

import numpy as onp                      # noqa: E402
import autograd.numpy as np              # noqa: E402
from autograd import value_and_grad      # noqa: E402

GRAPHS = ["none", "geo", "corr", "adp"]


# ----------------------------------------------------------------------------- torch .pt reader (no torch)
_DT = {"FloatStorage": onp.float32, "DoubleStorage": onp.float64, "LongStorage": onp.int64,
       "IntStorage": onp.int32, "HalfStorage": onp.float16, "BoolStorage": onp.bool_}


class _Storage:
    def __init__(self, name):
        self.dtype = _DT[name]


def _rebuild_tensor_v2(storage, offset, size, stride, *args):
    arr = storage
    if len(size) == 0:
        return arr[offset]
    return onp.lib.stride_tricks.as_strided(arr[offset:], shape=tuple(size),
                                            strides=tuple(s * arr.itemsize for s in stride)).copy()


def _rebuild_parameter(data, requires_grad, backward_hooks, *a):
    return data


def load_state_dict(path):
    z = zipfile.ZipFile(path)
    root = z.namelist()[0].split("/")[0]

    class U(pickle.Unpickler):
        def find_class(self, mod, name):
            if mod == "torch._utils" and name == "_rebuild_tensor_v2":
                return _rebuild_tensor_v2
            if mod == "torch._utils" and name == "_rebuild_parameter":
                return _rebuild_parameter
            if mod == "torch" and name in _DT:
                return _Storage(name)
            if mod == "collections" and name == "OrderedDict":
                return OrderedDict
            raise pickle.UnpicklingError(f"refusing {mod}.{name}")

        def persistent_load(self, pid):
            _, st, key, _loc, numel = pid
            raw = z.read(f"{root}/data/{key}")
            return onp.frombuffer(raw, dtype=st.dtype, count=numel)

    return U(z.open(f"{root}/data.pkl")).load()


# ----------------------------------------------------------------------------- model
def params_from_torch(sd):
    p = {"ts_W": sd["ts.weight"].T, "ts_b": sd["ts.bias"], "node": sd["node"],
         "np_W": sd["node_proj.weight"].T, "np_b": sd["node_proj.bias"], "tod": sd["tod"], "dow": sd["dow"],
         "e2": sd["e2"], "fuse_W": sd["fuse.weight"].T, "fuse_b": sd["fuse.bias"],
         "end_W": sd["end2.weight"].T, "end_b": sd["end2.bias"]}
    L = 0
    while f"mlp.{L}.0.weight" in sd:
        p[f"m{L}a_W"] = sd[f"mlp.{L}.0.weight"].T; p[f"m{L}a_b"] = sd[f"mlp.{L}.0.bias"]
        p[f"m{L}b_W"] = sd[f"mlp.{L}.3.weight"].T; p[f"m{L}b_b"] = sd[f"mlp.{L}.3.bias"]
        p[f"gw{L}"] = sd[f"gw.{L}"]
        L += 1
    if "cls.weight" in sd:
        p["cls_W"] = sd["cls.weight"].T; p["cls_b"] = sd["cls.bias"]
    return {k: onp.asarray(v, dtype=onp.float32) for k, v in p.items()}


def init_params(rng, N, T, F, H, n_slots, d=32, L=3, de=32, G=4, none_bias=2.0, aux=False):
    D = 4 * d

    def lin(i, o):
        b = 1 / onp.sqrt(i)
        return rng.uniform(-b, b, (i, o)).astype(onp.float32), rng.uniform(-b, b, o).astype(onp.float32)

    p = {}
    p["ts_W"], p["ts_b"] = lin(T * F, d)
    p["node"] = (rng.standard_normal((N, de)) * 0.1).astype(onp.float32)
    p["np_W"], p["np_b"] = lin(de, d)
    p["tod"] = (rng.standard_normal((n_slots, d)) * 0.1).astype(onp.float32)
    p["dow"] = (rng.standard_normal((7, d)) * 0.1).astype(onp.float32)
    p["e2"] = (rng.standard_normal((de, N)) * 0.1).astype(onp.float32)
    p["fuse_W"], fb = lin(de, G * L)
    fb = fb.reshape(L, G); fb[:, 0] = none_bias; p["fuse_b"] = fb.reshape(-1)
    lim = 0.1 * onp.sqrt(6.0 / (D + D))
    for l in range(L):
        p[f"m{l}a_W"], p[f"m{l}a_b"] = lin(D, D)
        p[f"m{l}b_W"], p[f"m{l}b_b"] = lin(D, D)
        p[f"gw{l}"] = rng.uniform(-lim, lim, (G, D, D)).astype(onp.float32)
    p["end_W"], p["end_b"] = lin(D, H)
    if aux:
        p["cls_W"], p["cls_b"] = lin(D, H * 3)
    return p


def fusion_weights(p, L, G=4):
    N = p["node"].shape[0]
    z = np.reshape(np.dot(p["node"], p["fuse_W"]) + p["fuse_b"], (N, L, G))
    z = z - np.max(z, -1, keepdims=True)
    e = np.exp(z)
    return e / np.sum(e, -1, keepdims=True)


def forward(p, b, Gm, L=3, drop=0.0, rng=None):
    """Gm: dict with 'geo_rw', 'corr_rw' (N x N). Returns dict(pred, [logits])."""
    x = b["x"]
    B, Tn, N, Fd = x.shape
    xf = onp.transpose(x, (0, 2, 1, 3)).reshape(B, N, Tn * Fd)
    h = np.dot(xf, p["ts_W"]) + p["ts_b"]
    nodep = np.dot(p["node"], p["np_W"]) + p["np_b"]
    tod = p["tod"][b["tod"][:, -1]]
    dow = p["dow"][b["dow"][:, -1]]
    ones = onp.ones((B, N, 1), onp.float32)
    h = np.concatenate([h, ones * nodep[None], ones * tod[:, None, :], ones * dow[:, None, :]], -1)
    a = np.maximum(np.dot(p["node"], p["e2"]), 0.0)
    a = a - np.max(a, 1, keepdims=True)
    A_adp = np.exp(a) / np.sum(np.exp(a), 1, keepdims=True)
    sups = [None, Gm["geo_rw"], Gm["corr_rw"], A_adp]
    if Gm.get("only_none"):                      # graph-free variant: no message passing at all
        sups = [None, None, None, None]
    alpha = fusion_weights(p, L)
    for l in range(L):
        u = np.maximum(np.dot(h, p[f"m{l}a_W"]) + p[f"m{l}a_b"], 0.0)
        if drop > 0 and rng is not None:
            u = u * (rng.random(u.shape) > drop) / (1 - drop)
        h = h + np.dot(u, p[f"m{l}b_W"]) + p[f"m{l}b_b"]
        z = 0.0
        for gi, A in enumerate(sups):
            if A is None:
                continue
            msg = np.matmul(A, h)                                   # (B,N,D)
            z = z + alpha[:, l, gi][None, :, None] * np.dot(msg, p[f"gw{l}"][gi])
        h = h + z
    out = np.transpose(np.dot(h, p["end_W"]) + p["end_b"], (0, 2, 1))   # (B,H,N)
    res = {"pred": b["last"][:, None, :] + out}
    if "cls_W" in p:
        lg = np.reshape(np.dot(h, p["cls_W"]) + p["cls_b"], (B, N, out.shape[1], 3))
        res["logits"] = np.transpose(lg, (0, 2, 1, 3))
    return res


def predict(p, data, Gm, split, bs=64, L=3):
    idx = data.idx[split]
    out = [onp.asarray(forward(p, data.batch(idx[i:i + bs]), Gm, L)["pred"]) for i in range(0, len(idx), bs)]
    return onp.concatenate(out, 0) * data.sd + data.mu


# ----------------------------------------------------------------------------- training (AdamW, one-cycle cosine)
def train(data, Gm, seed=0, rounds=25, batches=30, bs=32, lr=2e-3, wd=1e-4, patience=8, L=3, verbose=False, none_bias=2.0):
    rng = onp.random.default_rng(seed)
    p = init_params(rng, data.N, data.T_in, data.F, data.H, data.n_slots, L=L, none_bias=none_bias)
    keys = sorted(p)
    m = {k: onp.zeros_like(v) for k, v in p.items()}
    v2 = {k: onp.zeros_like(v) for k, v in p.items()}

    def loss(pp, b):
        return np.mean(np.abs(forward(pp, b, Gm, L, drop=0.15, rng=rng)["pred"] - b["y"]))

    vg = value_and_grad(loss)
    tr = data.idx["train"].copy()
    U = rounds * batches; u = 0
    yv = data.Z[data.idx["val"][:, None] + onp.arange(1, data.H + 1)[None]]
    best, best_p, bad, hist = onp.inf, None, 0, []
    b1, b2 = 0.9, 0.999
    for r in range(rounds):
        rng.shuffle(tr)
        for i in range(batches):
            frac = u / U
            pct = 0.05
            if frac < pct:
                cur = lr / 10 + (lr - lr / 10) * frac / pct
            else:
                q = (frac - pct) / (1 - pct)
                cur = lr / 200 + 0.5 * (lr - lr / 200) * (1 + onp.cos(onp.pi * q))
            b = data.batch(tr[i * bs:(i + 1) * bs])
            l, g = vg(p, b)
            gn = onp.sqrt(sum(float(onp.sum(g[k] ** 2)) for k in keys))
            sc = min(1.0, 5.0 / (gn + 1e-12))
            u += 1
            for k in keys:
                gk = g[k] * sc
                m[k] = b1 * m[k] + (1 - b1) * gk
                v2[k] = b2 * v2[k] + (1 - b2) * gk * gk
                mh = m[k] / (1 - b1 ** u); vh = v2[k] / (1 - b2 ** u)
                p[k] = (p[k] * (1 - cur * wd) - cur * mh / (onp.sqrt(vh) + 1e-8)).astype(onp.float32)
        pv = (predict(p, data, Gm, "val", L=L) - data.mu) / data.sd
        vmae = float(onp.mean(onp.abs(pv - yv)))
        hist.append(vmae)
        if verbose:
            print(f"round {r} val {vmae:.4f}", flush=True)
        if vmae < best - 1e-5:
            best, best_p, bad = vmae, {k: v.copy() for k, v in p.items()}, 0
        else:
            bad += 1
            if bad >= patience:
                break
    return best_p, best, hist
