"""Where does ramp predictability come from? (revision, analysis A)

For every forecast origin t of the original protocol (T = 12, H = 6, chronological 70/10/20 split) and
horizon h, the zone ramp y = (x_{t+h} - x_t) / m_i (m_i: zone mean training load) is regressed on four
groups of features that are all available at t:

  C  exogenous calendar, tariff and weather information: training-profile ramp of the zone over [t, t+h]
     (workday/off-day x time-of-day profile), time-of-day (sin/cos) and off-day flag of t+h, yesterday's
     scheduled price over the same interval (level at t+h-S and step p_{t+h-S} - p_{t-S}; tariffs repeat
     day-to-day in 97-99 % of zone-steps), and weather observed at t;
  O  the zone's own recent history: profile deviations at t..t-11 and the last two one-step ramps;
  D  daily-lag information: the zone's ramp over the same interval yesterday, x_{t+h-S} - x_t and the
     deviation at t+h-S, plus yesterday's ramp averaged over the zone's geographic neighbours, over its
     ramp-correlation neighbours and over the region (smoothed estimates of the same seasonal signal);
  N  the recent state of neighbour zones: profile deviations at t, ..., t-5 and the last one-step ramp, averaged
     over the zone's geographic k-NN neighbours (k = 10, no self loop) and over its ramp-correlation neighbours;
  R  the recent state of the region: regional profile deviations at t, ..., t-5 and the last regional ramp.
  N and R therefore carry only contemporaneous cross-sectional information, i.e. what a graph or a
  region-level message could add beyond the zone's own past and the calendar.

A pooled ridge regression, weighted by m_i^2 so that the loss is the squared ramp error in kW^2 (zone sizes span
three orders of magnitude), is fitted on the training origins for each of the 2^5 = 32 feature subsets and
each horizon; R^2 is measured on the test origins at zone level (pooled over zones, in kW) and at regional level
(sum of m_i * prediction, kW). Shapley values split the full-model R^2 among the five groups.
A pooled gradient-boosted tree model (HistGradientBoosting, sub-sampled training rows) is fitted at h = 1, 3, 6
on the full feature set and on each leave-one-group-out set, to check that the unique contribution of each
group does not hinge on linearity.
Output: out/predictability.json
"""
import itertools, json, math, os, sys, time
import importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))
import numpy as np
from pipeline import Data
from graphs import build_graphs, seasonal_profile

spec = importlib.util.spec_from_file_location("rawprice", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "revision_data", "data.py"))
rawprice = importlib.util.module_from_spec(spec); spec.loader.exec_module(rawprice)

GROUPS = ["C", "O", "D", "N", "R"]
NLAG = 6
NAMES = {"C": "Calendar, tariff & weather", "O": "Own recent history", "D": "Daily lag (own, neighbours, region)", "N": "Current state of neighbour zones", "R": "Current state of the region"}


def nomself(A):
    A = A.astype(np.float64).copy(); np.fill_diagonal(A, 0)
    return A / np.maximum(A.sum(1, keepdims=True), 1e-12)


def build(name, kappa=None):
    if kappa is None:
        D = Data(name)
    else:                                                  # semi-synthetic data with injected coupling (validation)
        import pipeline, semi_synth
        ds_aug, _ = semi_synth.augmented(name, kappa)
        orig = pipeline.load
        pipeline.load = lambda n: ds_aug
        try:
            D = pipeline.Data(name)
        finally:
            pipeline.load = orig
    ds = D.ds
    X = D.Traw
    T, N = X.shape
    S = D.spd
    n_tr = D.n_tr
    tod, off = ds["tod"], ds["offday"].astype(int)
    prof = seasonal_profile(X[:n_tr], tod[:n_tr], off[:n_tr], S)
    P = prof[off, tod]                                         # profile value at every step
    m = np.maximum(X[:n_tr].mean(0), 1.0)
    price = rawprice.load(name)["price"]
    G = build_graphs(ds, n_tr)
    Wg, Wc = nomself(G["A_geo"]), nomself(G["A_corr"])
    w = ds["weather"].astype(np.float64)
    w = (w - w[:n_tr].mean(0)) / (w[:n_tr].std(0) + 1e-9)
    dev = (X - P) / m                                          # relative deviation from calendar profile
    r1 = np.vstack([np.zeros((1, N)), np.diff(X, axis=0)]) / m  # relative one-step ramp
    regdev = (X - P).sum(1) / m.sum()
    regr1 = np.r_[0, np.diff(X.sum(1))] / m.sum()
    return dict(D=D, X=X, P=P, m=m, price=price, Wg=Wg, Wc=Wc, w=w, dev=dev, r1=r1, regdev=regdev,
                regr1=regr1, S=S, tod=tod, off=off, N=N)


def design(B, t, h):
    X, P, m, S, N = B["X"], B["P"], B["m"], B["S"], B["N"]
    n = len(t)
    col = {g: [] for g in GROUPS}
    bc = lambda v: np.broadcast_to(v[:, None], (n, N))
    # C
    col["C"].append((P[t + h] - P[t]) / m)
    ang = 2 * np.pi * B["tod"][t + h] / S
    col["C"] += [bc(np.sin(ang)), bc(np.cos(ang)), bc(B["off"][t + h].astype(float))]
    pr = B["price"]
    col["C"] += [pr[t + h - S], pr[t + h - S] - pr[t - S]]
    col["C"] += [bc(B["w"][t, j]) for j in range(B["w"].shape[1])]
    # O
    col["O"] += [B["dev"][t - k] for k in range(12)] + [B["r1"][t], B["r1"][t - 1]]
    # D
    yr = (X[t + h - S] - X[t - S]) / m
    col["D"] += [yr, (X[t + h - S] - X[t]) / m, B["dev"][t + h - S]]
    yreg = (X[t + h - S] - X[t - S]).sum(1) / m.sum()
    col["D"] += [yr @ B["Wg"].T, yr @ B["Wc"].T, bc(yreg)]
    # N: neighbours' recent state over the last NLAG steps (what message passing over the input window can see)
    for W in (B["Wg"], B["Wc"]):
        col["N"] += [B["dev"][t - k] @ W.T for k in range(NLAG)] + [B["r1"][t] @ W.T]
    # R
    col["R"] += [bc(B["regdev"][t - k]) for k in range(NLAG)] + [bc(B["regr1"][t])]
    out = {g: np.stack([c.reshape(n, N) for c in col[g]], -1).reshape(n * N, -1) for g in GROUPS}
    y = ((X[t + h] - X[t]) / m).reshape(-1)
    return out, y


def ridge_fit_predict(Xtr, ytr, Xte, w=None, lam=1e-3):
    """Weighted ridge (weights w = m_i^2 make the loss equal to the squared ramp error in kW^2)."""
    w = np.ones(len(ytr)) if w is None else w / w.mean()
    mu = (w[:, None] * Xtr).sum(0) / w.sum()
    sd = np.sqrt((w[:, None] * (Xtr - mu) ** 2).sum(0) / w.sum()) + 1e-9
    A = (Xtr - mu) / sd; Ate = (Xte - mu) / sd
    A1 = np.hstack([A, np.ones((len(A), 1))]); Ate1 = np.hstack([Ate, np.ones((len(Ate), 1))])
    G = A1.T @ (w[:, None] * A1); G[np.diag_indices_from(G)] += lam * len(A)
    G[-1, -1] -= lam * len(A)
    beta = np.linalg.solve(G, A1.T @ (w * ytr))
    return Ate1 @ beta


def scores(B, t, h, yhat_rel, y_rel):
    N, m = B["N"], B["m"]
    yh = yhat_rel.reshape(len(t), N); yy = y_rel.reshape(len(t), N)
    r2rel = 1 - np.sum((yh - yy) ** 2) / np.sum((yy - yy.mean()) ** 2)
    ek, yk = (yh - yy) * m, yy * m                           # kW
    r2z = 1 - np.sum(ek ** 2) / np.sum((yk - yk.mean()) ** 2)
    Yh = (yh * m).sum(1); Y = (yy * m).sum(1)
    r2r = 1 - np.sum((Yh - Y) ** 2) / np.sum((Y - Y.mean()) ** 2)
    maez = np.abs((yh - yy) * m).mean()
    maer = np.abs(Yh - Y).mean()
    return dict(R2_zone=float(r2z), R2_region=float(r2r), R2_zone_relative_units=float(r2rel),
                MAE_zone_kW=float(maez), MAE_region_kW=float(maer))


def shapley(v):
    """v: dict frozenset -> value. Returns dict group -> Shapley value."""
    n = len(GROUPS); phi = {}
    for g in GROUPS:
        others = [x for x in GROUPS if x != g]; s = 0.0
        for k in range(n):
            for Sset in itertools.combinations(others, k):
                wgt = math.factorial(k) * math.factorial(n - k - 1) / math.factorial(n)
                s += wgt * (v[frozenset(Sset) | {g}] - v[frozenset(Sset)])
        phi[g] = s
    return phi


def run(name, gbrt_h=(1, 3, 6), gbrt_rows=250_000, seed=0, kappa=None):
    B = build(name, kappa)
    D = B["D"]
    tr, te = D.idx["train"], D.idx["test"]
    res = {"ridge": {}, "gbrt": {}, "groups": NAMES}
    subsets = [frozenset(c) for k in range(len(GROUPS) + 1) for c in itertools.combinations(GROUPS, k)]
    for h in range(1, D.H + 1):
        Ftr, ytr = design(B, tr, h); Fte, yte = design(B, te, h)
        wtr = np.tile(B["m"] ** 2, len(tr))                    # row order of design(): origin-major, zone-minor
        vz, vr, allsc = {}, {}, {}
        for Sset in subsets:
            if not Sset:
                yhat = np.full_like(yte, ytr.mean())
            else:
                cols = [g for g in GROUPS if g in Sset]
                yhat = ridge_fit_predict(np.hstack([Ftr[g] for g in cols]), ytr, np.hstack([Fte[g] for g in cols]), w=wtr)
            sc = scores(B, te, h, yhat, yte)
            key = "".join(g for g in GROUPS if g in Sset) or "none"
            allsc[key] = sc; vz[Sset] = sc["R2_zone"]; vr[Sset] = sc["R2_region"]
        full = frozenset(GROUPS)
        res["ridge"][h] = dict(subsets=allsc, shapley_zone=shapley(vz), shapley_region=shapley(vr),
                               unique_zone={g: vz[full] - vz[full - {g}] for g in GROUPS},
                               unique_region={g: vr[full] - vr[full - {g}] for g in GROUPS})
        print(name, "ridge h", h, {k: round(v, 3) for k, v in res["ridge"][h]["shapley_zone"].items()},
              {k: round(v, 3) for k, v in res["ridge"][h]["shapley_region"].items()}, "full", allsc["CODNR"], flush=True)
        if h in gbrt_h:
            from sklearn.ensemble import HistGradientBoostingRegressor
            rng = np.random.default_rng(seed)
            sub = rng.choice(len(ytr), min(gbrt_rows, len(ytr)), replace=False)
            vz, vr, allsc = {}, {}, {}
            full = frozenset(GROUPS)
            gsubs = [frozenset(), full] + [full - {g} for g in GROUPS]
            for Sset in gsubs:
                if not Sset:
                    yhat = np.full_like(yte, ytr.mean())
                else:
                    cols = [g for g in GROUPS if g in Sset]
                    mdl = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, max_leaf_nodes=63,
                                                        min_samples_leaf=100, l2_regularization=1.0, random_state=seed)
                    mdl.fit(np.hstack([Ftr[g][sub] for g in cols]), ytr[sub], sample_weight=wtr[sub])
                    yhat = mdl.predict(np.hstack([Fte[g] for g in cols]))
                sc = scores(B, te, h, yhat, yte)
                key = "".join(g for g in GROUPS if g in Sset) or "none"
                allsc[key] = sc; vz[Sset] = sc["R2_zone"]; vr[Sset] = sc["R2_region"]
            uz = {g: vz[full] - vz[full - {g}] for g in GROUPS}
            ur = {g: vr[full] - vr[full - {g}] for g in GROUPS}
            res["gbrt"][h] = dict(subsets=allsc, unique_zone=uz, unique_region=ur)
            print(name, "gbrt h", h, {k: round(v, 3) for k, v in uz.items()}, {k: round(v, 3) for k, v in ur.items()},
                  "full", allsc["CODNR"], flush=True)
    return res


if __name__ == "__main__":
    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    if sys.argv[1:2] == ["--synthetic"]:              # ridge decomposition on UrbanEV with injected coupling
        kap = float(sys.argv[2])
        gb = (1, 3, 6) if sys.argv[3:4] == ["gbrt"] else ()
        r = run("UrbanEV", gbrt_h=gb, kappa=kap)
        suffix = "_gbrt" if gb else ""
        json.dump(r, open(os.path.join(HERE, "out", f"predictability_UrbanEV_synthetic_k{kap}{suffix}.json"), "w"), indent=1)
        sys.exit(0)
    names = sys.argv[1:] or ["UrbanEV", "ST-EVCDP"]
    for nm in names:
        t0 = time.time()
        r = run(nm)
        r["minutes"] = (time.time() - t0) / 60
        json.dump(r, open(os.path.join(HERE, "out", f"predictability_{nm}.json"), "w"), indent=1)
