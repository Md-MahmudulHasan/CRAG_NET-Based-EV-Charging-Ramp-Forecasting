"""Numbers quoted with Figs. 4 and 6: structure of the deseasonalised-ramp correlation and of the top-3 graphs."""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))
from data import load, split_index
from graphs import ramp_residual_corr
from graph_map import knn_edges

out = {}
for name in ["UrbanEV", "ST-EVCDP"]:
    ds = load(name)
    n_tr, _ = split_index(len(ds["X"]))
    X = ds["X"][:n_tr].astype(float)
    C = ramp_residual_corr(X, ds["tod"][:n_tr], ds["offday"][:n_tr], ds["steps_per_day"])
    D = ds["D"].astype(float)
    Eg, Ec = knn_edges(-D, 3), knn_edges(C, 3)
    iu = np.triu_indices(len(C), 1)
    hi = C[iu] > 0.3
    zones_hi = np.unique(np.concatenate([iu[0][hi], iu[1][hi]]))
    m = X.mean(0)
    out[name] = dict(
        n_zones=len(C),
        geo3_median_km=float(np.median([D[i, j] for i, j in Eg])),
        corr3_median_km=float(np.median([D[i, j] for i, j in Ec])),
        corr3_share_over_5km=float(np.mean([D[i, j] > 5 for i, j in Ec])),
        corr3_also_geo3=float(len(Ec & Eg) / len(Ec)),
        pairs_rho_gt_0p3=int(hi.sum()), share_pairs_rho_gt_0p3=float(hi.mean()),
        zones_in_rho_gt_0p3_pairs=int(len(zones_hi)),
        share_of_load_in_those_zones=float(m[zones_hi].sum() / m.sum()),
        median_km_of_rho_gt_0p3_pairs=float(np.median(D[iu][hi])) if hi.any() else None,
        median_km_all_pairs=float(np.median(D[iu])),
    )
json.dump(out, open(os.path.join(HERE, "out", "graph_numbers.json"), "w"), indent=1)
print(json.dumps(out, indent=1))

# distribution of pairwise correlations for the three matrices of Fig. 4 (UrbanEV, training split)
from graphs import seasonal_profile, deseasonalise
for name in ["UrbanEV", "ST-EVCDP"]:
    ds = load(name)
    n_tr, _ = split_index(len(ds["X"]))
    X = ds["X"][:n_tr].astype(float); tod = ds["tod"][:n_tr]; off = ds["offday"][:n_tr]
    R = deseasonalise(X, tod, off, seasonal_profile(X, tod, off, ds["steps_per_day"]))
    def corr(Y):
        Y = (Y - Y.mean(0)) / (Y.std(0) + 1e-9)
        return (Y.T @ Y) / len(Y)
    iu = np.triu_indices(X.shape[1], 1)
    d = {}
    for lab, Cm in [("raw_load", corr(X)), ("deseas_load", corr(R)), ("deseas_ramp", corr(np.diff(R, axis=0)))]:
        v = Cm[iu]
        d[lab] = dict(mean=float(v.mean()), share_lt_m0p2=float((v < -0.2).mean()), share_gt_0p3=float((v > 0.3).mean()),
                      share_gt_0p5=float((v > 0.5).mean()), share_abs_lt_0p1=float((np.abs(v) < 0.1).mean()))
    out[name]["corr_distribution"] = d
json.dump(out, open(os.path.join(HERE, "out", "graph_numbers.json"), "w"), indent=1)
print(json.dumps({k: v["corr_distribution"] for k, v in out.items()}, indent=1))
