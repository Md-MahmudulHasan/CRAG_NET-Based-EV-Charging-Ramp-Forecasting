"""Numbers quoted in the text for the horizon, hour-of-day and case-study figures (recomputed from the run files)."""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(REPO, "src"))
os.chdir(REPO)
import report as R
import pandas as pd
from pipeline import Data

out = {}
PRED = np.load(os.path.join(REPO, "results", "predictions_test_seedmean.npz"))
for ds in ["UrbanEV", "ST-EVCDP"]:
    runs = R.load_runs(ds)
    data = Data(ds)
    d = {"horizon": {}, "hour": {}}
    for t in ["SNaive-D", "SDiff", "GBRT", "STID", "GWNet", "AGCRN", "CRAG-Net", "abl_rampLoss"]:
        rs = [x for x in runs if x["tag"] == t]
        if not rs:
            continue
        d["horizon"][t] = {"zone_MAE_h": np.mean([x["zone"]["MAE_h"] for x in rs], 0).round(2).tolist(),
                           "region_MAE_h_MW": (np.mean([x["region"]["MAE_h"] for x in rs], 0) / 1e3).round(3).tolist(),
                           "region_F1_h": np.mean([x["ramp_region"]["F1_h"] for x in rs], 0).round(3).tolist()}
    y, _ = R.M._truth(data, "test")
    tt = data.idx["test"]
    fut = tt[:, None] + np.arange(1, data.H + 1)[None]
    hours = (data.ds["tod"][fut] * 24 / data.spd).astype(int)
    for t in ["SNaive-D", "GBRT", "STID", "CRAG-Net"]:
        P = PRED[f"{ds}__{t}"].astype(np.float64)  # released seed-averaged test forecasts (stored as float16)
        e = np.abs(P.sum(-1) - y.sum(-1)) / 1e3
        v = np.array([e[hours == h].mean() for h in range(24)])
        d["hour"][t] = {"by_hour_MW": v.round(2).tolist(), "overall_MW": float(e.mean()),
                        "share_err_in_00_07_08_12_13": float(sum(e[hours == h].sum() for h in (0, 7, 8, 12, 13)) / e.sum()),
                        "share_of_targets_in_those_hours": float(np.isin(hours, (0, 7, 8, 12, 13)).mean())}
    # case window as in report.case_fig
    ts = data.ds["ts"][data.idx["test"]]
    yr = y.sum(-1) / 1e3
    n = 4 * data.spd
    act = np.convolve(np.abs(np.diff(yr[:, 0])), np.ones(n), "valid")
    s0 = int(np.argmax(act[: len(act) - 1]))
    d["case_window"] = [str(pd.Timestamp(ts[s0])), str(pd.Timestamp(ts[s0 + n - 1]))]
    if ds == "UrbanEV":   # statistics of the plotted window, one-step-ahead (Fig. 11, upper panel)
        sl = slice(s0, s0 + n)
        tgt = pd.to_datetime(ts[sl]) + pd.Timedelta(hours=1)
        obs = yr[sl, 0]
        cs = {"target_first": str(tgt[0]), "target_last": str(tgt[-1])}
        mid = np.where(tgt.hour == 0)[0]
        cs["midnight_step_MW"] = [round(float(obs[i] - obs[i - 1]), 1) for i in mid if i > 0]
        for t in ["SNaive-D", "GBRT", "STID", "CRAG-Net"]:
            p = PRED[f"{ds}__{t}"].astype(np.float64).sum(-1)[sl, 0] / 1e3
            cs[t] = {"MAE_window_MW": round(float(np.mean(np.abs(p - obs))), 2),
                     "abs_err_at_00_MW": [round(float(abs(p[i] - obs[i])), 1) for i in mid]}
            cs[t]["pred_at"] = {str(tgt[i]): round(float(p[i]), 1) for i in range(len(tgt)) if tgt[i].hour == 5}
        cs["obs_at_05"] = {str(tgt[i]): round(float(obs[i]), 1) for i in range(len(tgt)) if tgt[i].hour == 5}
        d["case"] = cs
    out[ds] = d
json.dump(out, open(os.path.join(HERE, "out", "fig_numbers.json"), "w"), indent=1)
print(json.dumps(out, indent=1)[:200])
