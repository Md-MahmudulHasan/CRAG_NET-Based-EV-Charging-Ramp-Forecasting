"""Learned fusion weights of the released CRAG-Net checkpoints (3 seeds per dataset), read with the NumPy port."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))
import numpy as np
import np_crag
out = {}
for name in ["UrbanEV", "ST-EVCDP"]:
    A = []
    for s in range(3):
        p = np_crag.params_from_torch(np_crag.load_state_dict(os.path.join(HERE, "..", "results", "runs_torch", name, f"CRAG-Net_s{s}", "model.pt")))
        A.append(np.asarray(np_crag.fusion_weights(p, 3)))          # (N, L, G)
    A = np.stack(A)                                                  # (seed, N, L, G)
    per_zone = A.mean((0, 2))                                        # (N, G)
    out[name] = dict(mean=A.mean((0, 1, 2)).tolist(), per_zone=per_zone.tolist(),
                     null_largest_all_zones=bool((per_zone.argmax(1) == 0).all()),
                     null_min=float(per_zone[:, 0].min()), null_max=float(per_zone[:, 0].max()))
    print(name, np.round(out[name]["mean"], 3), out[name]["null_largest_all_zones"], round(out[name]["null_min"], 3), round(out[name]["null_max"], 3))
json.dump(out, open(os.path.join(HERE, "out", "real_alpha.json"), "w"))
