"""Fig. 3: response of zone charging ramps to a tariff step (event-study coefficients, 95% CI)."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, sys
sys.path.insert(0, os.path.join(REPO, "src"))
import numpy as np
import plotstyle as ps
import matplotlib.pyplot as plt

ps.setup()
d = json.load(open(os.path.join(REPO, "revision", "out", "price_sync.json")))
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.4), sharey=True)
for ax, (name, unit, col) in zip(axes, [("UrbanEV", 60, ps.CAT[0]), ("ST-EVCDP", 15, ps.CAT[1])]):
    es = d[name]["event_study"]
    lags = sorted(int(k) for k in es)
    eff = np.array([es[str(k)]["effect_pct_minus0p1"] for k in lags])
    se = np.array([es[str(k)]["se"] for k in lags]) * 0.1 * 100        # s.e. of the effect of a 0.1 CNY drop, % points
    x = np.array(lags) * unit
    ax.axhline(0, color=ps.AXIS, lw=0.8, zorder=1)
    ax.axvspan(-0.5 * unit, 0.5 * unit, color=ps.GRID, alpha=0.6, lw=0, zorder=0)
    ax.errorbar(x, eff, yerr=1.96 * se, fmt="o", color=col, ms=4.5, capsize=2.5, lw=1.2, zorder=3)
    ax.plot(x, eff, color=col, lw=1.0, alpha=0.6, zorder=2)
    for xi, yi in zip(x, eff):
        ax.annotate(f"{yi:.1f}", (xi, yi), xytext=(5, 4), textcoords="offset points", fontsize=6.5, color=ps.INK2)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{v:+d}" if v else "0" for v in x])
    ax.set_xlabel("Minutes relative to the tariff step")
    ax.set_title(f"{name} ({unit}-min steps, {d[name]['boundary_steps']} tariff-step times)", loc="left")
axes[0].set_ylabel("Ramp response to a 0.1 CNY/kWh\nprice drop (% of zone mean load)")
fig.tight_layout()
ps.save(fig, os.path.join(REPO, "revision_figures", "Fig3_event_study"))
print("ok")
