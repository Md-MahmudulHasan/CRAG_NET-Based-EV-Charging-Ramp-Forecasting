import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json
import os
RV = os.path.join(REPO, "revision", "out")
for name in ["UrbanEV", "ST-EVCDP"]:
    d = json.load(open(os.path.join(RV, f"predictability_{name}.json")))
    r, g = d["ridge"], d["gbrt"]
    print("==", name)
    for h in sorted(r, key=int):
        for lev in ["zone", "region"]:
            full = r[h]["subsets"]["CODNR"]["R2_" + lev]
            sh = r[h]["shapley_" + lev]; un = r[h]["unique_" + lev]
            share = {k: round(100 * v / full, 1) for k, v in sh.items()}
            line = f"h{h} {lev:6s} R2={full:.3f} shap%={share} uniq={ {k: round(v, 4) for k, v in un.items()} }"
            if h in g:
                gf = g[h]["subsets"]["CODNR"]["R2_" + lev]
                line += f" | GBRT R2={gf:.3f} uniq={ {k: round(v, 4) for k, v in g[h]['unique_' + lev].items()} }"
            print(line)
    # averages over horizons
    for lev in ["zone", "region"]:
        import numpy as np
        sh = {k: np.mean([r[h]["shapley_" + lev][k] / r[h]["subsets"]["CODNR"]["R2_" + lev] for h in r]) for k in "CODNR"}
        print("mean share", lev, {k: round(100 * v, 1) for k, v in sh.items()},
              "N+R share", round(100 * (sh["N"] + sh["R"]), 1),
              "max unique N", round(max(r[h]["unique_" + lev]["N"] for h in r), 4),
              "max unique R", round(max(r[h]["unique_" + lev]["R"] for h in r), 4))
