"""Graphical abstract (1328 x 531 px minimum; produced at 2656 x 1062 px). Uses only released result files."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, sys
sys.path.insert(0, os.path.join(REPO, "src"))
import numpy as np
import plotstyle as ps
import matplotlib.pyplot as plt

ps.setup()
plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "axes.labelsize": 8.5, "xtick.labelsize": 8, "ytick.labelsize": 8})
es = json.load(open(os.path.join(REPO, "revision", "out", "price_sync.json")))["UrbanEV"]["event_study"]
pr = json.load(open(os.path.join(REPO, "revision", "out", "predictability_UrbanEV.json")))["ridge"]
rs = json.load(open(os.path.join(REPO, "revision", "out", "reserve.json")))

fig, axes = plt.subplots(1, 3, figsize=(13.28, 5.31), dpi=200)
# 1 tariff response
ax = axes[0]
lags = [-2, -1, 0, 1, 2, 3]
eff = [es[str(k)]["effect_pct_minus0p1"] for k in lags]
se = [es[str(k)]["se"] * 10 for k in lags]
ax.axhline(0, color=ps.AXIS, lw=0.8)
ax.axvspan(-0.5, 0.5, color=ps.GRID, lw=0)
ax.errorbar(lags, eff, yerr=1.96 * np.array(se), fmt="o-", color=ps.CAT[0], ms=6, capsize=3, lw=1.6)
ax.set_xticks(lags); ax.set_xticklabels([f"{k:+d} h" if k else "step" for k in lags])
ax.set_ylabel("Zone ramp per 0.1 CNY/kWh price drop\n(% of zone mean load)")
ax.set_title("1  Tariff steps synchronise charging\n(same hour, zone by zone)", loc="left", fontweight="bold")
# 2 predictability
ax = axes[1]
G = ["C", "D", "O", "N", "R"]
lab = {"C": "Calendar & tariff", "D": "Daily lag", "O": "Own history", "N": "Neighbour zones", "R": "Region"}
col = {"C": ps.CAT[0], "O": ps.CAT[1], "D": ps.CAT[2], "N": ps.CAT[3], "R": ps.CAT[4]}
sh = {g: 100 * np.mean([pr[h]["shapley_zone"][g] / pr[h]["subsets"]["CODNR"]["R2_zone"] for h in pr]) for g in G}
y = np.arange(len(G))[::-1]
ax.barh(y, [sh[g] for g in G], color=[col[g] for g in G], height=0.62)
for yy, g in zip(y, G):
    ax.annotate(f"{sh[g]:.1f}%", (max(sh[g], 0), yy), xytext=(4, 0), textcoords="offset points", va="center", fontsize=8.5, color=ps.INK2)
ax.set_yticks(y); ax.set_yticklabels([lab[g] for g in G])
ax.set_xlim(0, 75); ax.set_xlabel("Share of explained ramp variance (UrbanEV, zone level)")
ax.set_title("2  Predictability is temporal,\nnot spatial", loc="left", fontweight="bold")
ax.grid(axis="y", visible=False)
# 3 reserve
ax = axes[2]
models = ["Persistence", "SNaive-D", "SDiff", "CRAG-Net"]
x = np.arange(len(models)); w = 0.38
for j, (name, c) in enumerate([("UrbanEV", ps.CAT[0]), ("ST-EVCDP", ps.CAT[1])]):
    v = [rs[name][m]["hourly"]["width_MW"] for m in models]
    ax.bar(x + (j - 0.5) * w, v, width=w * 0.92, color=c, label=name)
    for xx, vv in zip(x + (j - 0.5) * w, v):
        ax.annotate(f"{vv:.0f}", (xx, vv), xytext=(0, 2), textcoords="offset points", ha="center", fontsize=8, color=ps.INK2)
ax.set_xticks(x); ax.set_xticklabels(models)
ax.set_ylabel("95% ramp-reserve band (MW)")
ax.set_title("3  Better forecasts, smaller reserves\n(online conformal sizing)", loc="left", fontweight="bold")
ax.legend(loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(REPO, "revision_figures", "05_Graphical_abstract.png"), dpi=200)
fig.savefig(os.path.join(REPO, "revision_figures", "05_Graphical_abstract.pdf"))
from PIL import Image
print(Image.open(os.path.join(REPO, "revision_figures", "05_Graphical_abstract.png")).size)
