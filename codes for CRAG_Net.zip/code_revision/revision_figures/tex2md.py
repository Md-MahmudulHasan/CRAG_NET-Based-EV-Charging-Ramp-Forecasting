"""Convert the booktabs LaTeX tables released with the original study into Markdown pipe tables
(numbers are copied verbatim; only formatting is changed)."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import re, sys
import os


def conv_cell(c):
    c = c.strip()
    c = re.sub(r"\{\\scriptsize\$\\pm\$\{([^}]*)\}\}", r" ± \1", c)
    c = re.sub(r"\\textbf\{([^}]*)\}", r"**\1**", c)
    c = re.sub(r"\\underline\{([^}]*)\}", r"\1", c)
    c = c.replace("\\%", "%").replace("$\\overline{DM}$", "mean DM").replace("\\,", " ")
    c = re.sub(r"\\multicolumn\{\d+\}\{[^}]*\}\{([^}]*)\}", r"\1", c)
    c = re.sub(r"\\emph\{([^}]*)\}", r"*\1*", c)
    c = c.replace("$", "").replace("\\times", "×").replace("~", " ")
    return c


def tables(path):
    s = open(path).read()
    out = []
    for m in re.finditer(r"\\caption\{(.*?)\}\s*\n.*?\\begin\{tabular\}.*?\n(.*?)\\end\{tabular\}", s, re.S):
        cap, body = m.group(1), m.group(2)
        rows = []
        for line in body.split("\\\\"):
            line = re.sub(r"\\(toprule|midrule|bottomrule|cmidrule\([^)]*\)\{[^}]*\}|cmidrule\{[^}]*\})", "", line).strip()
            if not line:
                continue
            cells = [conv_cell(c) for c in line.split("&")]
            rows.append(cells)
        n = max(len(r) for r in rows)
        rows = [r + [""] * (n - len(r)) for r in rows]
        md = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * n]
        md += ["| " + " | ".join(r) + " |" for r in rows[1:]]
        out.append((conv_cell(re.sub(r"\\label\{[^}]*\}", "", cap)), "\n".join(md)))
    return out


if __name__ == "__main__":
    for p in sys.argv[1:]:
        for cap, md in tables(p):
            print("CAPTION:", cap)
            print(md)
            print()
