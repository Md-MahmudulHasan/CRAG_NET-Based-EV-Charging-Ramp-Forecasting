"""Fig. 7: are learned fusion weights evidence of spatial (in)dependence?
(a) learned null weight per zone on the real data (released checkpoints) vs its initial value;
(b) mean fusion weights at initialisation and after training on semi-synthetic UrbanEV data (kappa = coupling);
(c) test zone MAE with and without message passing."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, os, sys
sys.path.insert(0, os.path.join(REPO, "src"))
import numpy as np
import plotstyle as ps
import matplotlib.pyplot as plt

ps.setup()
RV = os.path.join(REPO, "revision", "out")
real = json.load(open(os.path.join(RV, "real_alpha.json")))
syn = {}
for f in os.listdir(RV):
    if f.startswith("synth_k") and f.endswith(".json"):
        v = json.load(open(os.path.join(RV, f)))
        syn[(v["kappa"], v["variant"])] = v
INIT_DEFAULT = syn[(1.0, "full")].get("alpha_init_mean") or json.load(open(os.path.join(RV, "alpha_init_default.json")))

fig = plt.figure(figsize=(7.0, 2.8))
gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.35, 0.95], wspace=0.45)

# (a) real data
ax = fig.add_subplot(gs[0])
for k, (name, c) in enumerate([("UrbanEV", ps.CAT[0]), ("ST-EVCDP", ps.CAT[1])]):
    pz = np.sort(np.array(real[name]["per_zone"])[:, 0])
    ax.plot(np.linspace(0, 1, len(pz)), pz, color=c, lw=1.5, label=name)
ax.axhline(INIT_DEFAULT[0], color=ps.INK2, ls="--", lw=1.0, label="initial value")
ax.set_ylim(0, 1); ax.set_xticks([])
ax.set_xlabel("Zones (sorted)")
ax.set_ylabel("Weight of the no-message option")
ax.set_title("(a) Real data", loc="left")
ax.legend(fontsize=6, loc="lower right")

# (b) semi-synthetic: null and geographic weight, initial vs learned
ax = fig.add_subplot(gs[1])
rows = []
for var, lab in [("full", "default init."), ("full_nb0", "neutral init.")]:
    for kap in (0.0, 0.5, 1.0):
        if (kap, var) in syn:
            rows.append((f"{kap:g}\n{'def.' if var == 'full' else 'neut.'}", syn[(kap, var)]))
x = np.arange(len(rows))
w = 0.2
for j, (g, c, lab) in enumerate([(0, ps.MUTED, "No message"), (1, ps.CAT[0], "Geographic graph")]):
    init = [r[1].get("alpha_init_mean", INIT_DEFAULT)[g] for r in rows]
    fin = [r[1]["alpha_mean"][g] for r in rows]
    ax.bar(x + (j - 0.5) * 2 * w, fin, width=w * 1.8, color=c, label=f"{lab} (trained)", zorder=3)
    ax.scatter(x + (j - 0.5) * 2 * w, init, marker="_", s=120, color=ps.INK, zorder=4, label="initial value" if j == 0 else None, linewidths=1.6)
ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows], fontsize=6.5)
ax.set_xlabel("κ (coupling) / initialisation", fontsize=7)
ax.set_ylim(0, 1)
ax.set_ylabel("Mean fusion weight")
ax.set_title("(b) Semi-synthetic UrbanEV", loc="left")
ax.legend(fontsize=6, loc="upper right")

# (c) accuracy with and without message passing, grouped by kappa
ax = fig.add_subplot(gs[2])
vars_ = [("full", ps.CAT[0], "Fusion, default init."), ("full_nb0", ps.CAT[2], "Fusion, neutral init."), ("nograph", ps.MUTED, "No message passing")]
kaps = [0.0, 1.0]
w = 0.26
for j, (v, c, lab) in enumerate(vars_):
    xs = [i + (j - 1) * w for i, k in enumerate(kaps) if (k, v) in syn]
    vals = [syn[(k, v)]["test"]["zone_MAE"] for k in kaps if (k, v) in syn]
    ax.bar(xs, vals, width=w * 0.92, color=c, label=lab, zorder=3)
    for xx, vv in zip(xs, vals):
        ax.annotate(f"{vv:.1f}", (xx, vv), xytext=(0, 1.5), textcoords="offset points", ha="center", fontsize=5.5, color=ps.INK2)
ax.set_xticks(range(len(kaps))); ax.set_xticklabels([f"κ = {k:g}" for k in kaps])
ax.set_ylim(0, 68)
ax.set_ylabel("Test zone MAE (kW)")
ax.set_title("(c) Accuracy", loc="left")
ax.legend(fontsize=5.5, loc="upper center", ncol=1, frameon=False)
fig.subplots_adjust(left=0.07, right=0.99, bottom=0.22, top=0.88)
ps.save(fig, os.path.join(REPO, "revision_figures", "Fig11_fusion"))
print("ok")
