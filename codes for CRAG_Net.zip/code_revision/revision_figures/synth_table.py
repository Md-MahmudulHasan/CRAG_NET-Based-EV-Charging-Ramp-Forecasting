"""Table 7 of the main text: semi-synthetic experiment (Markdown), from the released result files."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, os
RV = os.path.join(REPO, "revision", "out")
syn = {}
for f in os.listdir(RV):
    if f.startswith("synth_k") and f.endswith(".json"):
        v = json.load(open(os.path.join(RV, f)))
        syn[(v["kappa"], v["variant"])] = v
init_def = json.load(open(os.path.join(RV, "alpha_init_default.json")))
dec = {0.0: json.load(open(os.path.join(RV, "predictability_UrbanEV.json")))["ridge"],
       1.0: json.load(open(os.path.join(RV, "predictability_UrbanEV_synthetic_k1.0_gbrt.json")))["ridge"]}
VN = {"full": "Fusion (null bias +2)", "full_nb0": "Fusion (neutral init.)", "nograph": "No message passing"}
lines = ["| $\\kappa$ | Injected share of residual variance | Model | Test zone MAE (kW) | Test regional MAE (MW) | Null weight: initial → trained | Geographic weight: initial → trained | Unique $R^2$ of N (zone / region) |",
         "|---|---|---|---|---|---|---|---|"]
for kap in (0.0, 0.5, 1.0):
    first = True
    for var in ("full", "full_nb0", "nograph"):
        if (kap, var) not in syn:
            continue
        v = syn[(kap, var)]
        inj = f"{100 * v.get('injected_share_of_residual_var', 0):.0f}%" if first else ""
        if var == "nograph":
            a0 = a1 = "–"
        else:
            ini = v.get("alpha_init_mean") or init_def
            a0 = f"{ini[0]:.2f} → {v['alpha_mean'][0]:.2f}"
            a1 = f"{ini[1]:.2f} → {v['alpha_mean'][1]:.2f}"
        if first and kap in dec:
            fmt = lambda x: "≤ 0" if x <= 0.0005 else f"{x:.3f}"
            d = dec[kap]
            u = f"{fmt(max(d[h]['unique_zone']['N'] for h in d))} / {fmt(max(d[h]['unique_region']['N'] for h in d))}"
        else:
            u = "–" if first else ""
        lines.append(f"| {kap:g} | {inj} | {VN[var]} | {v['test']['zone_MAE']:.1f} | {v['test']['region_MAE'] / 1000:.2f} | {a0} | {a1} | {u} |")
        first = False
print("\n".join(lines))
