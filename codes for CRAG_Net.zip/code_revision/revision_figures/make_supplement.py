"""Build the Supplementary Material (Markdown) directly from the released result files, so that every
number is copied from an output file rather than transcribed by hand."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tex2md import tables

T = os.path.join(REPO, "results", "tables")
RV = os.path.join(REPO, "revision", "out")
OUT = os.path.join(REPO, "revision_figures", "Supplementary_Material.md")


def tab(path, idx=0, header_fix=None, drop_italic=True):
    cap, md = tables(os.path.join(T, path))[idx]
    lines = md.split("\n")
    if header_fix:
        lines = header_fix(lines)
    if drop_italic:
        lines = [l.replace("\\textit{", "*").replace("} |", "* |") if "\\textit" in l else l for l in lines]
    return "\n".join(lines)


def fix_dm(lines):
    return ["| Competitor | Regional error: better/worse | Regional error: mean DM | Zone-mean error: better/worse | Zone-mean error: mean DM |",
            "|---|---|---|---|---|"] + lines[3:]


def fix_daylag(lines):
    return ["| Data | Model | Zone MAE (kW), with lag | Zone MAE (kW), without | Region ramp F1, with | Region ramp F1, without |",
            "|---|---|---|---|---|---|"] + lines[3:]


def fix_abl(lines):
    return ["| Variant | UrbanEV zone MAE (kW) | UrbanEV reg. MAE (MW) | UrbanEV zone F1 | UrbanEV reg. F1 | UrbanEV reg. event MAE (MW) | ST-EVCDP zone MAE (kW) | ST-EVCDP reg. MAE (MW) | ST-EVCDP zone F1 | ST-EVCDP reg. F1 | ST-EVCDP reg. event MAE (MW) |",
            "|---|---|---|---|---|---|---|---|---|---|---|"] + lines[3:]


def clean_main(lines):
    return [l.replace(" (ours)", "") for l in lines]


ps = json.load(open(os.path.join(REPO, "revision", "out", "price_sync.json")))
res = json.load(open(os.path.join(RV, "reserve_g0.01.json")))
res5 = json.load(open(os.path.join(RV, "reserve_g0.005.json")))
pred = {n: json.load(open(os.path.join(RV, f"predictability_{n}.json"))) for n in ["UrbanEV", "ST-EVCDP"]}
synth = {}
for f in sorted(os.listdir(RV)):
    if f.startswith("synth_k") and f.endswith(".json"):
        synth[f] = json.load(open(os.path.join(RV, f)))
psyn = os.path.join(RV, "predictability_UrbanEV_synthetic_k1.0_gbrt.json")
psyn = json.load(open(psyn)) if os.path.exists(psyn) else None

S = []
S.append("""---
title: "Supplementary Material — Correlation- and ramp-aware learning for regional electric-vehicle charging ramps: Tariffs, not neighbours, drive predictability"
---

This document accompanies the main article. Section, table and figure numbers prefixed with "S" refer to this document; all others refer to the main article. All numbers are generated from the released result files.

# S1. Full benchmark tables
""")
S.append("Table S1. Test-set accuracy and ramp metrics on UrbanEV (deep models: mean ± s.d. over three seeds; best in bold). CRAG-Net-R is CRAG-Net trained with the ramp-aware objective.\n\n" + tab("main_tables.tex", 0, clean_main) + "\n")
S.append("Table S2. Test-set accuracy and ramp metrics on ST-EVCDP (deep models: mean ± s.d. over three seeds; best in bold).\n\n" + tab("main_tables.tex", 1, clean_main) + "\n")
S.append("Table S3. Model size and training cost (UrbanEV, PyTorch, one CPU thread; mean over seeds). Baseline configurations: LSTM, T-GCN and one-layer AGCRN with hidden size 64; STGCN channels (32, 16, 32); GWNet 32 residual and 64 skip channels, eight dilated layers; STID hidden size 32, three MLP layers; iTransformer model dimension 64, two layers; STAEformer one temporal and one spatial Transformer layer of dimension 48.\n\n" + tab("cost.tex") + "\n")
S.append("Table S4. Diebold–Mariano tests (Harvey–Leybourne–Newbold correction) of CRAG-Net against each competitor, per horizon on seed-averaged absolute errors. Entries: number of horizons (of six) at which CRAG-Net is significantly better / worse at p < 0.05, and the mean DM statistic (negative favours CRAG-Net). The first ten rows are UrbanEV, the last ten ST-EVCDP.\n\n" + tab("dm.tex", 0, fix_dm) + "\n")
S.append("Table S4b. Full ablation of CRAG-Net (test, mean ± s.d. over three seeds).\n\n" + tab("ablation.tex", 0, fix_abl) + "\n")
S.append("Table S4c. Effect of the day-ahead-aligned daily-lag channel (test, mean over seeds).\n\n" + tab("daylag.tex", 0, fix_daylag) + "\n")
S.append("Table S4d. The ramp-aware objective applied to STID and CRAG-Net (test, mean over three seeds; -R = ramp-aware). Zone MAE in kW, regional MAE and regional event MAE in MW.\n\n" + tab("objective.tex").replace("Reg.\\ ", "Reg. ") + "\n")
S.append("Table S4e. Robustness to training budget (three times the updates, \"long\", three seeds) and to baseline size (Graph WaveNet with its published 256/512 skip/end channels, seed 0 only). Test zone MAE (kW) / regional MAE (MW).\n\n" + tab("sensitivity.tex").replace("``long''", "\"long\"") + "\n")

S.append("""
# S2. CRAG-Net details: objective, priors and model selection

*Ramp-aware objective (CRAG-Net-R).* The multi-task loss is $\\mathcal L=\\overline{w|\\hat z-z|}+\\lambda_s\\overline{|\\delta\\hat z-\\delta z|}+\\lambda_r\\overline{|N^{-1}\\sum_i(\\hat z_i-z_i)|}+\\lambda_c\\,\\mathrm{CE}(\\hat{\\mathbf p},c)$, where $w=1+\\beta\\min(|\\Delta|/\\theta,3)$ up-weights samples with large observed ramps ($\\theta$: the zone- and horizon-specific event threshold), $\\delta$ denotes step-to-step differences including the step from the origin, the third term penalises the error of the regional aggregate and the last term is a class-weighted cross-entropy for an auxiliary three-class (down, none, up) ramp-event head. We use $\\beta=0.5$, $\\lambda_s=0.25$, $\\lambda_r=0.5$ and $\\lambda_c=0.05$. The objective is model-agnostic: applied to STID it improves the regional metrics in the same way (Table S4d).

*Gated seasonal ramp priors (ablation only).* We also tested adding $\\tanh(\\gamma^D_{h,i})(z_{t+h-S,i}-z_{t-S,i})+\\tanh(\\gamma^P_{h,i})(P_i(t+h)-P_i(t))$ to the ramp head, with gates that are linear in $\\mathbf h^{(L)}_i$ and initialised at zero ($P_i$: training calendar profile). The priors hurt on UrbanEV and made no difference on ST-EVCDP (Table S4b), probably because the encoder already receives the daily-lag channel; they are not part of the final model.

*Model selection.* The final configuration was chosen on the validation splits of both datasets with seed 0 among: a gated dilated TCN backbone (as in Graph WaveNet) with the same fusion and priors, and the MLP encoder with and without graphs, with and without the null option and with and without the priors. The MLP encoder with null-option fusion and no priors had the lowest mean normalised validation MAE over the two datasets (0.0511, against 0.0512 without graphs, 0.0521 with zero-initialised priors and 0.0537 for the TCN backbone). All variants are reported as ablations on the test sets with three seeds.

*Implementation.* All deep models were implemented in PyTorch with tensor layout (batch, time, node, channel). For the revision, the released CRAG-Net checkpoints were also loaded into an independent NumPy implementation (with automatic differentiation from the autograd package for training); it reproduces the released test forecasts to within float16 storage precision, and was used to generate validation-period forecasts (Section 7 of the main article) and to train CRAG-Net on semi-synthetic data (Section 6).
""")

# ---------------------------------------------------------------- S3 price regression
rows = ["| | UrbanEV | ST-EVCDP |", "|---|---|---|"]
u, s_ = ps["UrbanEV"], ps["ST-EVCDP"]
rows.append(f"| Zones / tariff-step times / zone-step observations | {u['zones']} / {u['boundary_steps']:,} / {u['same_step']['n']:,} | {s_['zones']} / {s_['boundary_steps']:,} / {s_['same_step']['n']:,} |")
rows.append(f"| Share of zone-steps with a price change at tariff-step times | {100*u['share_zone_steps_with_change']:.1f}% | {100*s_['share_zone_steps_with_change']:.1f}% |")
rows.append(f"| Mean absolute price step when changing (CNY/kWh) | {u['mean_abs_step_when_changing']:.3f} | {s_['mean_abs_step_when_changing']:.3f} |")
for lag in ["-2", "-1", "0", "1", "2", "3"]:
    a, b = u["event_study"][lag], s_["event_study"][lag]
    rows.append(f"| $\\beta_{{{lag}}}$ (s.e.; t) | {a['beta']:.3f} ({a['se']:.3f}; {a['t']:.2f}) | {b['beta']:.3f} ({b['se']:.3f}; {b['t']:.2f}) |")
for k, lab in [("same_step_drops_only", "Same step, price drops only"), ("same_step_rises_only", "Same step, price rises only")]:
    a, b = u[k], s_[k]
    rows.append(f"| {lab}: $\\beta$ (s.e.; t) | {a['beta']:.3f} ({a['se']:.3f}; {a['t']:.2f}) | {b['beta']:.3f} ({b['se']:.3f}; {b['t']:.2f}) |")
S.append("""
# S3. Price-step panel regression

The regression of Eq. (2) is estimated on the balanced panel of all zones at every step at which at least 5% of zones change price; the dependent variable is the zone's one-step ramp at offset $\\ell$ relative to the step, divided by its mean training load, and the regressor is the zone's price step (CNY/kWh). Two-way (time and zone) fixed effects are removed by double demeaning; standard errors are clustered by zone with the usual small-sample correction. $\\beta_\\ell$ is the change of the relative ramp per CNY/kWh, so a 0.1 CNY/kWh price *drop* changes the ramp by $-0.1\\beta_\\ell\\times100$ % of mean load. "Drops only" and "rises only" regress the ramp on the negative and positive parts of the price step separately.

Table S5. Price-step panel regression (Eq. (2)).

""" + "\n".join(rows) + "\n")

# ---------------------------------------------------------------- S4 predictability
GN = {"C": "Calendar, tariff & weather", "O": "Own recent history", "D": "Daily lag", "N": "Neighbour zones (recent)", "R": "Region (recent)"}
S.append("""
# S4. Predictability decomposition: full results

Table S6 lists, for every horizon, the out-of-sample $R^2$ of the full pooled ridge model and the Shapley share and unique contribution (loss of $R^2$ when the group is removed) of each information group; Table S7 gives the unique contributions in the gradient-boosted tree model. Zone-level $R^2$ is pooled over zones in kW; the regression is weighted by the squared mean zone load, so that the loss is the squared ramp error in kW$^2$.
""")
for name in ["UrbanEV", "ST-EVCDP"]:
    r = pred[name]["ridge"]
    hdr = "| h | Level | Full $R^2$ | " + " | ".join(f"Shapley {g}" for g in "CODNR") + " | " + " | ".join(f"Unique {g}" for g in "CODNR") + " |"
    lines = [hdr, "|" + "---|" * 13]
    for h in sorted(r, key=int):
        for lev, sk, uk, fk in [("zone", "shapley_zone", "unique_zone", "R2_zone"), ("region", "shapley_region", "unique_region", "R2_region")]:
            full = r[h]["subsets"]["CODNR"][fk]
            lines.append(f"| {h} | {lev} | {full:.3f} | " + " | ".join(f"{r[h][sk][g]:.3f}" for g in "CODNR") + " | " + " | ".join(f"{r[h][uk][g]:.3f}" for g in "CODNR") + " |")
    S.append(f"Table S6{'a' if name == 'UrbanEV' else 'b'}. Ridge decomposition, {name} (C calendar/tariff/weather, O own history, D daily lag, N current state of neighbour zones, R current state of the region).\n\n" + "\n".join(lines) + "\n")
lines = ["| Data | h | Level | Full $R^2$ | " + " | ".join(f"Unique {g}" for g in "CODNR") + " |", "|" + "---|" * 9]
for name in ["UrbanEV", "ST-EVCDP"]:
    gb = pred[name]["gbrt"]
    for h in sorted(gb, key=int):
        for lev, uk, fk in [("zone", "unique_zone", "R2_zone"), ("region", "unique_region", "R2_region")]:
            lines.append(f"| {name} | {h} | {lev} | {gb[h]['subsets']['CODNR'][fk]:.3f} | " + " | ".join(f"{gb[h][uk][g]:.3f}" for g in "CODNR") + " |")
S.append("Table S7. Gradient-boosted trees (HistGradientBoosting, 300 iterations, learning rate 0.08, 63 leaves, min. 100 samples per leaf, 250,000 sub-sampled training rows): full-model $R^2$ and unique contribution of each group.\n\n" + "\n".join(lines) + "\n")
if psyn is not None:
    r, gb = psyn["ridge"], psyn["gbrt"]
    real = pred["UrbanEV"]
    lines = ["| h | Level | Ridge: full $R^2$ | Ridge: Shapley N | Ridge: unique N (real data) | Ridge: unique N | GBRT: unique N (real data) | GBRT: unique N |", "|---|---|---|---|---|---|---|---|"]
    for h in sorted(r, key=int):
        for lev, sk, uk, fk in [("zone", "shapley_zone", "unique_zone", "R2_zone"), ("region", "shapley_region", "unique_region", "R2_region")]:
            g1 = f"{real['gbrt'][h][uk]['N']:.3f}" if h in gb else "–"
            g2 = f"{gb[h][uk]['N']:.3f}" if h in gb else "–"
            lines.append(f"| {h} | {lev} | {r[h]['subsets']['CODNR'][fk]:.3f} | {r[h][sk]['N']:.3f} | {real['ridge'][h][uk]['N']:.3f} | {r[h][uk]['N']:.3f} | {g1} | {g2} |")
    S.append("Table S8. Validation of the decomposition on semi-synthetic UrbanEV data with injected neighbour coupling ($\\kappa=1$, Section 6): Shapley share and unique contribution of the neighbour group N, with the unique contribution on the real data for comparison.\n\n" + "\n".join(lines) + "\n")

# ---------------------------------------------------------------- S5 semi-synthetic
if synth:
    lines = ["| $\\kappa$ | Variant | Injected share of residual variance | Test zone MAE (kW) | Test regional MAE (MW) | Mean fusion weight: null / geo / corr / adaptive | Best val. MAE (norm.) | Rounds |", "|---|---|---|---|---|---|---|---|"]
    for f, v in sorted(synth.items(), key=lambda kv: (kv[1]["kappa"], kv[1]["variant"])):
        a = v.get("alpha_mean")
        aw = " / ".join(f"{x:.3f}" for x in a) if v["variant"] != "nograph" else "— (no message passing)"
        lines.append(f"| {v['kappa']:.1f} | {v['variant']} | {v.get('injected_share_of_residual_var', 0):.3f} | {v['test']['zone_MAE']:.2f} | {v['test']['region_MAE']/1000:.3f} | {aw} | {v['best_val']:.4f} | {len(v['hist'])} |")
    S.append("""
# S5. Semi-synthetic coupling experiment: details

Loads are modified as $x'_{t,i}=x_{t,i}\\exp(\\gamma\\kappa\\,z_{t-3,i})$ with $\\gamma=0.25$, where $z_{t,i}=\\sum_j W_{ij}r_{t,j}/\\mathrm{sd}$ is the standardised geographic-neighbour average (row-normalised 10-NN graph without self-loops) of the zone-standardised deseasonalised residuals $r$. The lag of three steps lies inside the 12-step input window. The multiplicative form keeps loads non-negative. Graphs, profiles, normalisation and thresholds are re-estimated on the modified training data, and CRAG-Net is retrained from scratch with the protocol of Section 5.1 (one seed per setting). "nograph" removes all message passing (only the null option); "full_nb0" initialises the null-option bias at 0 instead of +2 (uniform initial fusion weights).

Table S9. Semi-synthetic experiment (UrbanEV).

""" + "\n".join(lines) + "\n")

# ---------------------------------------------------------------- S6 reserve sensitivity
lines = ["| Data | Forecast | $\\gamma$ | Static coverage (%) | Static width (MW) | Static IS | Hourly coverage (%) | Hourly width (MW) | Hourly IS |", "|---|---|---|---|---|---|---|---|---|"]
for name in ["UrbanEV", "ST-EVCDP"]:
    for m in ["Persistence", "SNaive-D", "SDiff", "CRAG-Net"]:
        for g, dd in [("0.01", res), ("0.005", res5)]:
            a, b = dd[name][m]["static"], dd[name][m]["hourly"]
            lines.append(f"| {name} | {m} | {g} | {100*a['coverage']:.1f} | {a['width_MW']:.1f} | {a['interval_score']:.1f} | {100*b['coverage']:.1f} | {b['width_MW']:.1f} | {b['interval_score']:.1f} |")
lines2 = ["| Data | Forecast | " + " | ".join(f"h={h}" for h in range(1, 7)) + " |", "|" + "---|" * 8]
for name in ["UrbanEV", "ST-EVCDP"]:
    for m in ["SNaive-D", "SDiff", "CRAG-Net"]:
        lines2.append(f"| {name} | {m} | " + " | ".join(f"{w:.1f} ({100*c:.1f}%)" for w, c in zip(res[name][m]["hourly"]["width_h"], res[name][m]["hourly"]["coverage_h"])) + " |")
S.append("""
# S6. Reserve sizing: sensitivity and horizon detail

Table S10. Sensitivity of the online reserve bands to the adaptive-conformal step size $\\gamma$ (all horizons pooled).

""" + "\n".join(lines) + """

Table S11. Hour-conditional 95% band width (MW) and empirical coverage by forecast horizon ($\\gamma=0.01$).

""" + "\n".join(lines2) + "\n")

S.append("""
# S7. Supplementary figures

![Fig. S1. ST-EVCDP training period: mean regional ramp rate into each hour, share of hours with a regional ramp event and median zone price (as Fig. 2 for UrbanEV).](figures/FigS1_tariff_ramps_STEVCDP.png){width=100%}

![Fig. S2. ST-EVCDP pairwise correlation versus centroid distance (as Fig. 5 for UrbanEV).](figures/FigS2_corr_distance_STEVCDP.png){width=100%}

![Fig. S3. Regional absolute error by hour of the target time (all horizons pooled; seed-averaged forecasts) for SNaive-D, GBRT, the most accurate deep baseline (STID) and CRAG-Net. The five target hours around the tariff steps (00:00, 07:00–08:00 and 12:00–13:00) carry 30% (UrbanEV) and 35% (ST-EVCDP) of CRAG-Net's absolute regional error but make up 21% of the forecasts (Section 5.3).](figures/FigS3_hour_error.png){width=100%}
""")
open(OUT, "w").write("\n".join(S).replace("w/o day-lag channel", "w/o daily-lag channel"))
print("written", OUT)
