"""Fig. 8: width of the 95% ramp-reserve band by target hour (hour-conditional scheme, online ACI sizing)."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, sys
sys.path.insert(0, os.path.join(REPO, "src"))
import numpy as np
import plotstyle as ps
import matplotlib.pyplot as plt

ps.setup()
d = json.load(open(os.path.join(REPO, "revision", "out", "reserve.json")))
models = [("SNaive-D", ps.CAT[1], "s"), ("SDiff", ps.CAT[3], "^"), ("CRAG-Net", ps.CAT[0], "o")]
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.5), sharey=True)
for ax, name in zip(axes, ["UrbanEV", "ST-EVCDP"]):
    rh = d[name]["ramp_hours"]
    for hh in rh:
        ax.axvspan(hh - 0.5, hh + 0.5, color=ps.GRID, alpha=0.7, lw=0, zorder=0)
    hrs = np.arange(24)
    for m, c, mk in models:
        w = d[name][m]["hourly"]["width_by_target_hour"]
        ax.plot(hrs, w, color=c, marker=mk, ms=3.2, lw=1.3, label=f"{m} (hour-conditional)", zorder=3)
    ws = d[name]["CRAG-Net"]["static"]["width_MW"]
    ax.axhline(ws, color=ps.CAT[0], ls="--", lw=1.0, zorder=2, label="CRAG-Net (static band)")
    ax.set_xticks(range(0, 24, 3))
    ax.set_xlim(-0.6, 23.6)
    ax.set_xlabel("Target hour of day")
    ax.set_title(f"{name} (shaded: ramp hours {', '.join(f'{h:02d}:00' for h in rh)})", loc="left")
axes[0].set_ylabel("Width of 95% reserve band (MW)")
axes[0].set_ylim(0, None)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.06))
fig.tight_layout(rect=(0, 0.07, 1, 1))
ps.save(fig, os.path.join(REPO, "revision_figures", "Fig12_reserve"))
print("ok")
