"""Fig. 5: Shapley decomposition of out-of-sample ramp R^2 by information source (pooled ridge)."""
import os
import sys
REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")  # repository root
import json, sys
sys.path.insert(0, os.path.join(REPO, "src"))
import numpy as np
import plotstyle as ps
import matplotlib.pyplot as plt

ps.setup()
G = ["C", "O", "D", "N", "R"]
LAB = {"C": "Calendar, tariff & weather", "O": "Own recent history", "D": "Daily lag",
       "N": "Neighbour zones (recent)", "R": "Region (recent)"}
COL = {"C": ps.CAT[0], "O": ps.CAT[1], "D": ps.CAT[2], "N": ps.CAT[3], "R": ps.CAT[4]}
fig, axes = plt.subplots(2, 2, figsize=(6.8, 4.4), sharey="row")
for j, name in enumerate(["UrbanEV", "ST-EVCDP"]):
    d = json.load(open(os.path.join(REPO, "revision", "out", f"predictability_{name}.json")))["ridge"]
    hs = sorted(int(h) for h in d)
    step = 60 if name == "UrbanEV" else 15
    for i, (lev, key) in enumerate([("Zone ramps", "shapley_zone"), ("Regional ramp", "shapley_region")]):
        ax = axes[i, j]
        pos = np.zeros(len(hs)); neg = np.zeros(len(hs))
        for g in G:
            v = np.array([d[str(h)][key][g] for h in hs])
            bottom = np.where(v >= 0, pos, neg)
            ax.bar(hs, v, bottom=bottom, color=COL[g], width=0.72, edgecolor="white", linewidth=0.8,
                   label=LAB[g] if (i == 0 and j == 0) else None, zorder=3)
            pos += np.where(v >= 0, v, 0); neg += np.where(v < 0, v, 0)
        full = np.array([d[str(h)]["subsets"]["CODNR"]["R2_zone" if i == 0 else "R2_region"] for h in hs])
        for h, f in zip(hs, full):
            ax.annotate(f"{f:.2f}", (h, f), xytext=(0, 2), textcoords="offset points", ha="center", fontsize=6.5,
                        color=ps.INK2)
        ax.set_xticks(hs)
        ax.set_xticklabels([f"{h * step // 60}h" if step == 60 else f"{h * step}'" for h in hs])
        ax.axhline(0, color=ps.AXIS, lw=0.8)
        ax.set_ylim(min(-0.02, neg.min() - 0.02), 1.05)
        if j == 0:
            ax.set_ylabel(f"{lev}: out-of-sample $R^2$")
        if i == 0:
            ax.set_title(name, loc="left")
        if i == 1:
            ax.set_xlabel("Forecast horizon")
h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.02), fontsize=6.8)
fig.tight_layout(rect=(0, 0.05, 1, 1))
ps.save(fig, os.path.join(REPO, "revision_figures", "Fig7_decomposition"))
print("ok")
