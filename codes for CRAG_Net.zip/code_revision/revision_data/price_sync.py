"""Price-step synchronisation analysis (new in the revision).

Question: at the same moment, do zones whose charging price falls by more show a larger charging ramp?
Panel: all zones x all steps at which at least 5% of zones change price (tariff boundaries).
y_{t,i} = (x_{t,i} - x_{t-1,i}) / mean_train(x_i)    (ramp relative to the zone's mean load)
dp_{t,i} = p_{t,i} - p_{t-1,i}                        (CNY/kWh)
Two-way fixed effects (time step, zone); standard errors clustered by zone.
Also reported: the same regression for the following step (t+1), to capture delayed response, and an
event-study profile for steps t-2 .. t+3 in which the two leads act as placebo (pre-trend) tests.
Output: ../data_out/price_sync.json
"""
import json, os
import numpy as np
from data import load

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "revision", "out")
os.makedirs(OUT, exist_ok=True)


def twoway(y, x):
    """y, x: (Tsel, N) balanced panel. Returns beta, clustered SE (by zone), n."""
    def dm(a):
        return a - a.mean(0, keepdims=True) - a.mean(1, keepdims=True) + a.mean()
    yd, xd = dm(y), dm(x)
    beta = (xd * yd).sum() / (xd * xd).sum()
    e = yd - beta * xd
    # cluster by zone (columns)
    s = ((xd * e).sum(0) ** 2).sum()
    Tn, N = y.shape
    dof = N / (N - 1) * (Tn * N - 1) / (Tn * N - 2 - (Tn - 1) - (N - 1))
    se = np.sqrt(dof * s) / (xd * xd).sum()
    return float(beta), float(se), int(Tn * N)


res = {}
for nm in ["UrbanEV", "ST-EVCDP"]:
    D = load(nm)
    x, P = D["x"], D["price"]
    n_tr = D["n_tr"]
    xm = x[:n_tr].mean(0)
    keep = xm > 1.0                                      # drop zones with (near) zero training load
    x, P, xm = x[:, keep], P[:, keep], xm[keep]
    dx = np.diff(x, axis=0) / xm                        # relative ramp at step t (t = 1..)
    dp = np.diff(P, axis=0)
    sel = np.where((np.abs(dp) > 1e-6).mean(1) >= 0.05)[0]
    sel = sel[(sel + 3 < len(dx)) & (sel - 2 >= 0)]
    out = {"zones": int(keep.sum()), "boundary_steps": int(len(sel))}
    out["event_study"] = {}
    for lag in range(-2, 4):                       # leads (-2, -1) are placebo tests: no effect expected
        b, se, n = twoway(dx[sel + lag], dp[sel])
        out["event_study"][str(lag)] = {"beta": b, "se": se, "t": b / se, "effect_pct_minus0p1": -0.1 * b * 100}
    for lag, name in [(0, "same_step"), (1, "next_step")]:
        b, se, n = twoway(dx[sel + lag], dp[sel])
        out[name] = {"beta_rel_ramp_per_CNY": b, "se": se, "t": b / se, "n": n,
                     "effect_of_minus_0p1_CNY_pct_of_mean_load": -0.1 * b * 100}
    # asymmetry: price drops vs rises
    for sgn, name in [(-1, "drops"), (1, "rises")]:
        m = np.where(np.sign(dp[sel]) == sgn, dp[sel], 0.0)
        b, se, n = twoway(dx[sel], m)
        out[f"same_step_{name}_only"] = {"beta": b, "se": se, "t": b / se}
    # share of zone-steps at boundaries with a price change, and mean |step|
    ch = np.abs(dp[sel]) > 1e-6
    out["share_zone_steps_with_change"] = float(ch.mean())
    out["mean_abs_step_when_changing"] = float(np.abs(dp[sel][ch]).mean())
    res[nm] = out
    print(nm, json.dumps(out, indent=1))
json.dump(res, open(os.path.join(OUT, "price_sync.json"), "w"), indent=1)
