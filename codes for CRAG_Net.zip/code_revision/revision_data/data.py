"""Data loading and windowing for the CRAG-Net revision analyses.

Reproduces the protocol of the original manuscript (Sections 3 and 5):
UrbanEV  : 275 zones, hourly,  2022-09-01..2023-02-28 (4,344 steps), S = 24
ST-EVCDP : 247 zones, 5-min aggregated to 15-min (2,880 steps), S = 96
Chronological 70/10/20 split; forecast origins t whose targets t+1..t+H fall inside the split and
t >= S + T - 1 - H (so that the day-ahead-aligned daily-lag channel is defined). T = 12, H = 6.
Load in kW per zone; regional load = sum over zones (MW in reports).
"""
import os
import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "raw")
T_IN, H = 12, 6

# Chinese public holidays and official make-up working days inside the two periods
HOLIDAYS = pd.to_datetime([
    "2022-09-10", "2022-09-11", "2022-09-12",                      # Mid-Autumn Festival
    "2022-10-01", "2022-10-02", "2022-10-03", "2022-10-04", "2022-10-05", "2022-10-06", "2022-10-07",  # National Day
    "2022-12-31", "2023-01-01", "2023-01-02",                      # New Year
    "2023-01-21", "2023-01-22", "2023-01-23", "2023-01-24", "2023-01-25", "2023-01-26", "2023-01-27",  # Spring Festival
]).date
MAKEUP_WORKDAYS = pd.to_datetime(["2022-10-08", "2022-10-09", "2023-01-28", "2023-01-29"]).date


def offday(ts):
    d = ts.date()
    if d in MAKEUP_WORKDAYS:
        return 0
    if d in HOLIDAYS:
        return 1
    return int(ts.weekday() >= 5)


def load(name):
    if name == "UrbanEV":
        df = pd.read_csv(os.path.join(ROOT, "UrbanEV", "data", "volume.csv"), index_col=0, parse_dates=True)
        x = df.values.astype(float)                      # kWh per hour == mean kW
        price = pd.read_csv(os.path.join(ROOT, "UrbanEV", "data", "e_price.csv"), index_col=0, parse_dates=True)
        price = price[df.columns].values.astype(float)
        idx = df.index
        S = 24
        zones = list(df.columns)
        dist = pd.read_csv(os.path.join(ROOT, "UrbanEV", "data", "distance.csv"), index_col=0)
        adj = pd.read_csv(os.path.join(ROOT, "UrbanEV", "data", "adj.csv"), index_col=0)
    elif name == "ST-EVCDP":
        d = os.path.join(ROOT, "ST-EVCDP", "datasets")
        df = pd.read_csv(os.path.join(d, "volume.csv"), index_col=0)
        tm = pd.read_csv(os.path.join(d, "time.csv"), encoding="utf-8-sig")
        idx5 = pd.to_datetime(dict(year=tm.year, month=tm.month, day=tm.day, hour=tm.hour, minute=tm.minute))
        zones = list(df.columns)
        v5 = df.values.astype(float)                     # kWh per 5 min
        v15 = v5.reshape(-1, 3, v5.shape[1]).sum(1)      # kWh per 15 min
        x = v15 * 4.0                                     # mean kW over the 15-min step
        p5 = pd.read_csv(os.path.join(d, "price.csv"), index_col=0)[zones].values.astype(float)
        price = p5.reshape(-1, 3, p5.shape[1]).mean(1)
        idx = pd.DatetimeIndex(idx5.values[::3])
        S = 96
        dist = pd.read_csv(os.path.join(d, "distance.csv"), index_col=0)
        adj = pd.read_csv(os.path.join(d, "adj.csv"), index_col=0)
    else:
        raise ValueError(name)
    n = len(x)
    n_tr = int(round(0.7 * n)); n_va = int(round(0.1 * n))
    t0 = S + T_IN - 1 - H
    origins = {"train": np.arange(t0, n_tr - H), "val": np.arange(n_tr - 1, n_tr + n_va - H),
               "test": np.arange(n_tr + n_va - 1, n - H)}
    off = np.array([offday(ts) for ts in idx])
    return dict(name=name, x=x, price=price, idx=idx, S=S, zones=zones, n_tr=n_tr, n_va=n_va,
                origins=origins, off=off, dist=dist, adj=adj)


def targets(D, split):
    """Array (anchors, H, N) of target loads x_{t+h}."""
    o = D["origins"][split]
    return np.stack([D["x"][o + h] for h in range(1, H + 1)], axis=1)
