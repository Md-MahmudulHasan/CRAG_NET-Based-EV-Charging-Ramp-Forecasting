"""Deterministic statistical baselines and evaluation metrics (reproduce Tables 3-4 of the original manuscript)."""
import numpy as np
from data import H


def tod(D):
    S = D["S"]
    return np.arange(len(D["x"])) % S if D["name"] == "ST-EVCDP" else D["idx"].hour.values


def profile(D):
    """Calendar profile P_i(tod, offday) estimated on the training split (steps < n_tr)."""
    x, S, off = D["x"], D["S"], D["off"]
    td = (D["idx"].hour.values * (S // 24) + D["idx"].minute.values // (60 // (S // 24)))
    P = np.zeros((2, S, x.shape[1]))
    for o in (0, 1):
        for s in range(S):
            m = (td[:D["n_tr"]] == s) & (off[:D["n_tr"]] == o)
            P[o, s] = x[:D["n_tr"]][m].mean(0) if m.any() else x[:D["n_tr"]][td[:D["n_tr"]] == s].mean(0)
    return P, td


def forecast(D, split, kind):
    x, S = D["x"], D["S"]
    o = D["origins"][split]
    out = np.zeros((len(o), H, x.shape[1]))
    if kind == "HA":
        P, td = profile(D)
    for h in range(1, H + 1):
        if kind == "Persistence":
            out[:, h - 1] = x[o]
        elif kind == "SNaive-D":
            out[:, h - 1] = x[o + h - S]
        elif kind == "SNaive-W":
            out[:, h - 1] = x[o + h - 7 * S]
        elif kind == "SDiff":
            out[:, h - 1] = x[o] + x[o + h - S] - x[o - S]
        elif kind == "HA":
            tt = o + h
            out[:, h - 1] = P[D["off"][tt], td[tt]]
    return out


def thresholds(D, level):
    """90th-percentile |cumulative ramp| on the training split, per horizon (and per zone for level='zone')."""
    x = D["x"]; o = D["origins"]["train"]
    th = []
    for h in range(1, H + 1):
        if level == "zone":
            th.append(np.percentile(np.abs(x[o + h] - x[o]), 90, axis=0))
        else:
            X = x.sum(1); th.append(np.percentile(np.abs(X[o + h] - X[o]), 90))
    return np.array(th)


def event_scores(obs_ramp, fc_ramp, th):
    """Directional ramp events: observed |ramp| > th; hit only if forecast event has the same sign."""
    ob = np.sign(obs_ramp) * (np.abs(obs_ramp) > th)
    fc = np.sign(fc_ramp) * (np.abs(fc_ramp) > th)
    tp = np.sum((ob != 0) & (fc == ob)); fp = np.sum((fc != 0) & (fc != ob)); fn = np.sum((ob != 0) & (fc != ob))
    f1 = 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else 0.0
    csi = tp / (tp + fp + fn) if tp + fp + fn else 0.0
    return f1, csi


def evaluate(D, split, fc):
    """fc: (anchors, H, N) kW. Returns dict of metrics averaged over horizons."""
    x = D["x"]; o = D["origins"][split]
    y = np.stack([x[o + h] for h in range(1, H + 1)], 1)
    e = fc - y
    X0 = x[o].sum(1)
    Y = y.sum(2); F = fc.sum(2)
    thz = thresholds(D, "zone"); thr = thresholds(D, "region")
    zf1 = []; rf1 = []; rcsi = []; ev = []
    for h in range(H):
        zf1.append(event_scores(y[:, h] - x[o], fc[:, h] - x[o], thz[h][None, :])[0])
        f1, csi = event_scores(Y[:, h] - X0, F[:, h] - X0, thr[h]); rf1.append(f1); rcsi.append(csi)
        m = np.abs(Y[:, h] - X0) > thr[h]
        ev.append(np.abs(F[:, h] - Y[:, h])[m].mean() / 1000)
    return dict(zoneMAE=np.abs(e).mean(), zoneRMSE=np.sqrt((e ** 2).mean(axis=(0, 2))).mean(),
                WMAPE=100 * np.abs(e).sum() / np.abs(y).sum(),
                regMAE=np.abs(F - Y).mean() / 1000, regRMSE=np.sqrt(((F - Y) ** 2).mean(0)).mean() / 1000,
                zoneF1=np.mean(zf1), regF1=np.mean(rf1), regCSI=np.mean(rcsi), regEvMAE=np.mean(ev))
